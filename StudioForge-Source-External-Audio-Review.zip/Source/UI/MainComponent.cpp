#include "MainComponent.h"
#include "../Midi/MidiFileImporter.h"
#include "../Project/ProjectSerializer.h"
#include "../Project/ProjectState.h"
#include "StudioForgeDialog.h"

MainComponent::MainComponent()
{
    juce::LookAndFeel::setDefaultLookAndFeel(&lookAndFeel);
    setLookAndFeel(&lookAndFeel);
    addAndMakeVisible(controlBar);
    addAndMakeVisible(arrangeWindow);
    addChildComponent(inspectorPane);
    addChildComponent(assetBrowser);
    addChildComponent(mixerPane);
    addChildComponent(pianoRoll);
    addAndMakeVisible(startupWorkflow);

    // Keep the selected channel's controls in view by default, matching the
    // arrangement-first workflow rather than starting with a blank left rail.
    inspectorPane.setVisible(true);
    controlBar.setInspectorVisible(true);
    assetBrowser.setVisible(false);
    controlBar.setBrowserVisible(false);

    workspaceModeController = std::make_unique<WorkspaceModeController>(audioEngine,
        [this](const WorkspaceProfile& profile) { applyWorkspaceMode(profile); });

    controlBar.onMixerToggle = [this]
    {
        const auto visible = ! mixerPane.isVisible();
        mixerPane.setVisible(visible);
        controlBar.setMixerVisible(visible);
        resized();
    };
    controlBar.onInspectorToggle = [this]
    {
        const auto visible = ! inspectorPane.isVisible();
        inspectorPane.setVisible(visible);
        controlBar.setInspectorVisible(visible);
        resized();
    };
    controlBar.onPianoRollToggle = [this]
    {
        const auto visible = ! pianoRoll.isVisible();
        pianoRoll.setVisible(visible);
        controlBar.setPianoRollVisible(visible);
        resized();
    };
    controlBar.onBrowserToggle = [this]
    {
        setBrowserPanelVisible(! assetBrowser.isVisible());
    };
    controlBar.onCreateTrack = [this](TrackType)
    {
        configureTrackCreationDialog();
        startupWorkflow.setVisible(true);
        startupWorkflow.showTrackCreation(true);
    };
    controlBar.onRecordRequested = [this] { toggleRecording(); };
    controlBar.onWorkspaceModeChanged = [this](WorkspaceMode mode)
    {
        if (const auto result = workspaceModeController->requestMode(mode); result.failed())
            controlBar.setWorkspaceMode(workspaceModeController->getActiveMode());
    };
    controlBar.onCountInChanged = [this](bool enabled) { countInEnabled = enabled; };
    controlBar.onCountInBarsChanged = [this](int bars) { countInBars = juce::jlimit(1, 2, bars); };
    controlBar.onPunchChanged = [this](bool enabled)
    {
        if (! enabled)
        {
            trackDataModel.clearPunchRange();
            return;
        }

        if (trackDataModel.isCycleActive())
        {
            trackDataModel.setPunchRange(trackDataModel.getCycleStartSample(), trackDataModel.getCycleEndSample());
            return;
        }

        const auto samplesPerBeat = trackDataModel.getSampleRate() * 60.0 / trackDataModel.getBpm();
        const auto start = trackDataModel.getPlayheadPosition();
        trackDataModel.setPunchRange(start, start + samplesPerBeat * trackDataModel.getTimeSignatureNumerator());
    };
    startupWorkflow.onTemplateSelected = [this] (ProjectTemplate projectTemplate)
    {
        createProjectFromTemplate(projectTemplate);
    };
    startupWorkflow.onOpenProject = [this]
    {
        if (onOpenProjectRequested != nullptr)
            onOpenProjectRequested();
    };
    startupWorkflow.onOpenRecentProject = [this](const juce::File& file)
    {
        if (onOpenRecentProjectRequested != nullptr)
            onOpenRecentProjectRequested(file);
    };
    startupWorkflow.onAudioDeviceSettingsRequested = [this]
    {
        if (onAudioDeviceSettingsRequested)
            onAudioDeviceSettingsRequested();
    };
    startupWorkflow.onAudioInputChannelSelected = [this](int channel) { selectAudioInputChannel(channel); };
    startupWorkflow.onAudioOutputChannelSelected = [this](int channel) { selectAudioOutputChannel(channel); };
    startupWorkflow.onPerformanceConfigured = [this](const LiveSetupConfig& setup)
    {
        audioEngine.setPlaybackState(false);
        enableAvailablePerformanceInputs();
        const auto result = trackDataModel.applyProjectState(ProjectTemplates::createLiveSetup(setup));
        if (result.failed())
            return;

        repairAudioTrackInputAssignments();

        // A Performance Room is immediately playable: every configured source
        // is armed, while audio sources monitor only when armed.
        const auto* device = audioEngine.getAudioDeviceManager().getCurrentAudioDevice();
        const auto availableInputs = device != nullptr ? device->getActiveInputChannels().countNumberOfSetBits() : 0;
        auto nextAudioInput = 0;
        auto hasExternalMidi = false;
        for (size_t index = 0; index < trackDataModel.getTrackCount(); ++index)
        {
            const auto& track = trackDataModel.getTrack(index);
            if (track.type == TrackType::audio)
            {
                const auto input = availableInputs > 0 ? nextAudioInput++ % availableInputs : 0;
                trackDataModel.setTrackInputConfiguration(index, true, false,
                                                          input, 1);
            }
            hasExternalMidi = hasExternalMidi || track.type == TrackType::externalMidi;
            trackDataModel.setTrackArmed(index, true);
        }

        audioEngine.prepareActiveEffects();
        selectTrack(0);
        mixerPane.refreshFromModel();
        arrangeWindow.repaint();
        pianoRoll.repaint();
        markProjectSaved();
        showWorkspace();
        if (hasExternalMidi && audioEngine.getMidiOutputDeviceIdentifier().isEmpty())
            juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::InfoIcon,
                                                   "MIDI Hardware needs an output",
                                                   "Your hardware MIDI tracks are ready. Choose the target device in Device Settings > MIDI OUTPUT.");
    };
    arrangeWindow.onTrackSelected = [this](int track) { selectTrack(track); };
    arrangeWindow.onPerformanceSetupRequested = [this]
    {
        configureTrackCreationDialog();
        startupWorkflow.setVisible(true);
        startupWorkflow.showTrackCreation(true);
    };
    arrangeWindow.onAudioClipSelected = [this](ClipId) {};
    arrangeWindow.onMidiClipSelected = [this](MidiClipId clip)
    {
        pianoRoll.setActiveClip(clip);
        pianoRoll.setVisible(true);
        controlBar.setPianoRollVisible(true);
        resized();
    };
    assetBrowser.onAudioFileActivated = [this](const juce::File& file)
    {
        importAudioFile(file);
    };

    // A project starts empty; tracks are created through the explicit New Track workflow.
    markProjectSaved();
    startTimerHz(30);

    const juce::Component::SafePointer<MainComponent> safeThis(this);
    juce::Timer::callAfterDelay(1, [safeThis]
    {
        if (safeThis != nullptr)
            safeThis->audioEngine.initialise();
    });
}

void MainComponent::requestTuneAiUrlAnalysis()
{
    auto* dialog = new juce::AlertWindow("Analyze YouTube / Karaoke",
                                         "Paste a YouTube or YouTube Music URL. Tune-AI will analyze it only after you confirm.",
                                         juce::MessageBoxIconType::QuestionIcon);
    dialog->addTextEditor("url", {}, "YouTube URL:");
    dialog->addButton("Analyze", 1, juce::KeyPress(juce::KeyPress::returnKey));
    dialog->addButton("Cancel", 0, juce::KeyPress(juce::KeyPress::escapeKey));
    const auto safeThis = juce::Component::SafePointer<MainComponent>(this);
    const auto safeDialog = juce::Component::SafePointer<juce::AlertWindow>(dialog);
    dialog->enterModalState(true, juce::ModalCallbackFunction::create([safeThis, safeDialog] (int button)
    {
        if (button == 1 && safeThis != nullptr && safeDialog != nullptr)
            safeThis->startTuneAiUrlAnalysis(safeDialog->getTextEditorContents("url"));
    }), true);
}

void MainComponent::startTuneAiUrlAnalysis(const juce::String& rawUrl)
{
    const auto url = rawUrl.trim();
    if (! (url.containsIgnoreCase("youtube.com") || url.containsIgnoreCase("youtu.be")))
    {
        StudioForgeDialog::showWarning("Tune-AI Analysis", "Enter a valid YouTube or YouTube Music URL.");
        return;
    }

    const auto safeThis = juce::Component::SafePointer<MainComponent>(this);
    juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::InfoIcon,
                                           "Tune-AI Analysis",
                                           "Analysis started. Tune-AI is reading the karaoke audio in the background.\n\n"
                                           "This usually takes 30–120 seconds for a new video. Do not start it again; "
                                           "StudioForge will show the detected key when it finishes.");
    tuneAiAnalysis.analyseYouTubeUrlAsync(url, [safeThis] (TuneAiAnalysisService::Result result)
    {
        if (safeThis == nullptr) return;
        if (! result.succeeded)
        {
            StudioForgeDialog::showWarning("Tune-AI Analysis Failed", result.error);
            return;
        }

        const auto applied = safeThis->audioEngine.applyKeyToPitchCorrection(result.rootNote, result.minor);
        static constexpr const char* noteNames[] { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
        const auto key = juce::String(noteNames[result.rootNote]) + (result.minor ? " minor" : " major");
        auto message = (result.fromCache ? "Cached result: " : "Analysis complete: ") + key
            + " (confidence " + juce::String(result.confidence, 2) + ").";
        if (result.title.isNotEmpty()) message << "\n" << result.title;
        message << (applied > 0
                        ? "\nApplied directly to " + juce::String(applied) + " VibeAutotune instance(s)."
                        : "\nNo VibeAutotune instance is inserted, so no plug-in parameter was changed.");
        juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::InfoIcon, "Tune-AI Analysis", message);
    });
}

void MainComponent::showInitialTrackCreation()
{
    configureTrackCreationDialog();
    startupWorkflow.setVisible(true);
    startupWorkflow.showTrackCreation(false);
}

void MainComponent::configureTrackCreationDialog()
{
    const auto* device = audioEngine.getAudioDeviceManager().getCurrentAudioDevice();
    const auto inputs = device != nullptr ? device->getActiveInputChannels().countNumberOfSetBits() : 0;
    const auto outputs = device != nullptr ? device->getActiveOutputChannels().countNumberOfSetBits() : 0;
    startupWorkflow.setAudioDeviceChannels(inputs, outputs);
}

void MainComponent::enableAvailablePerformanceInputs()
{
    auto& deviceManager = audioEngine.getAudioDeviceManager();
    auto* device = deviceManager.getCurrentAudioDevice();
    if (device == nullptr)
        return;

    const auto inputCount = device->getInputChannelNames().size();
    if (inputCount <= 0)
        return;

    auto setup = deviceManager.getAudioDeviceSetup();
    setup.inputChannels.clear();
    for (int channel = 0; channel < inputCount; ++channel)
        setup.inputChannels.setBit(channel);
    if (deviceManager.setAudioDeviceSetup(setup, true).isEmpty())
        audioEngine.saveAudioDeviceState();
    repairAudioTrackInputAssignments();
    configureTrackCreationDialog();
}

void MainComponent::repairAudioTrackInputAssignments()
{
    const auto* device = audioEngine.getAudioDeviceManager().getCurrentAudioDevice();
    if (device == nullptr)
        return;

    const auto active = device->getActiveInputChannels();
    if (active.countNumberOfSetBits() == 0)
        return;

    juce::Array<int> availableInputs;
    for (int channel = active.findNextSetBit(0); channel >= 0; channel = active.findNextSetBit(channel + 1))
        availableInputs.add(channel);

    auto nextInput = 0;
    for (size_t index = 0; index < trackDataModel.getTrackCount(); ++index)
    {
        const auto& track = trackDataModel.getTrack(index);
        if (track.type != TrackType::audio)
            continue;

        const auto current = track.inputChannel.load(std::memory_order_relaxed);
        if (availableInputs.contains(current))
            continue;

        // Preserve the user's monitor choice. This only repairs source
        // indexes that vanished after connecting a smaller interface.
        trackDataModel.setTrackInputConfiguration(index,
            track.autoInputMonitoring.load(std::memory_order_relaxed),
            track.inputMonitoring.load(std::memory_order_relaxed),
            availableInputs[nextInput++ % availableInputs.size()], 1);
    }
}

void MainComponent::selectAudioInputChannel(int oneBasedChannel)
{
    auto& deviceManager = audioEngine.getAudioDeviceManager();
    auto setup = deviceManager.getAudioDeviceSetup();
    setup.inputChannels.clear();
    setup.inputChannels.setBit(oneBasedChannel - 1);
    deviceManager.setAudioDeviceSetup(setup, true);
    audioEngine.saveAudioDeviceState();
    repairAudioTrackInputAssignments();
    configureTrackCreationDialog();
}

void MainComponent::selectAudioOutputChannel(int oneBasedChannel)
{
    auto& deviceManager = audioEngine.getAudioDeviceManager();
    auto setup = deviceManager.getAudioDeviceSetup();
    setup.outputChannels.clear();
    setup.outputChannels.setBit(oneBasedChannel - 1);
    setup.outputChannels.setBit(oneBasedChannel);
    deviceManager.setAudioDeviceSetup(setup, true);
    audioEngine.saveAudioDeviceState();
    repairAudioTrackInputAssignments();
    configureTrackCreationDialog();
}

MainComponent::~MainComponent()
{
    stopTimer();
    if (&juce::LookAndFeel::getDefaultLookAndFeel() == &lookAndFeel)
        juce::LookAndFeel::setDefaultLookAndFeel(nullptr);
    setLookAndFeel(nullptr);
}

void MainComponent::applyWorkspaceMode(const WorkspaceProfile& profile)
{
    const auto mode = profile.mode;
    if (workspaceMode == mode)
        return;

    // The project model is never touched here. Workspace modes only alter UI
    // priority and the global audio policy; per-track monitoring remains the
    // track's own explicit state.
    if (workspaceMode == WorkspaceMode::studio)
    {
        studioInspectorVisible = inspectorPane.isVisible();
        studioMixerVisible = mixerPane.isVisible();
        studioBrowserVisible = assetBrowser.isVisible();
        studioTrackHeight = trackDataModel.getTrackHeight();
    }

    if (mode == WorkspaceMode::studio)
    {
        inspectorPane.setVisible(studioInspectorVisible);
        mixerPane.setVisible(studioMixerVisible);
        assetBrowser.setVisible(studioBrowserVisible);
        controlBar.setInspectorVisible(studioInspectorVisible);
        controlBar.setMixerVisible(studioMixerVisible);
        controlBar.setBrowserVisible(studioBrowserVisible);
        trackDataModel.setTrackHeight(studioTrackHeight);
    }
    else if (mode == WorkspaceMode::stage)
    {
        // Stage prioritises large strips and meters; no project or mixer
        // values are reset and returning to Studio restores the snapshot.
        inspectorPane.setVisible(false);
        assetBrowser.setVisible(false);
        pianoRoll.setVisible(false);
        mixerPane.setVisible(true);
        controlBar.setInspectorVisible(false);
        controlBar.setBrowserVisible(false);
        controlBar.setPianoRollVisible(false);
        controlBar.setMixerVisible(true);
        trackDataModel.setTrackHeight(104);
    }
    else // stream
    {
        // Stream keeps the focused vocal controls accessible while retaining
        // the arrangement and shared engine/project state.
        inspectorPane.setVisible(true);
        assetBrowser.setVisible(false);
        pianoRoll.setVisible(false);
        mixerPane.setVisible(false);
        controlBar.setInspectorVisible(true);
        controlBar.setBrowserVisible(false);
        controlBar.setPianoRollVisible(false);
        controlBar.setMixerVisible(false);
        trackDataModel.setTrackHeight(88);
    }

    workspaceMode = mode;
    resized();
    arrangeWindow.repaint();
}

bool MainComponent::keyPressed(const juce::KeyPress& key)
{
    return handleGlobalKeyPress(key);
}

bool MainComponent::handleGlobalKeyPress(const juce::KeyPress& key)
{
    if (key.getModifiers().isAltDown() && key.getKeyCode() == '\'')
    {
        arrangeWindow.addMarkerAtPlayhead();
        return true;
    }
    if ((key.getKeyCode() == 'z' || key.getKeyCode() == 'Z')
        && ! key.getModifiers().isCommandDown() && ! key.getModifiers().isCtrlDown())
    {
        if (key.getModifiers().isShiftDown())
            arrangeWindow.fitTracksToWindow();
        else if (! key.getModifiers().isAnyModifierKeyDown())
            arrangeWindow.toggleSelectedTrackZoom();
        else
            return false;
        return true;
    }
    if (key.getModifiers().isAnyModifierKeyDown())
        return false;

    if (key.isKeyCode(juce::KeyPress::spaceKey))
    {
        handleSpaceTransport();
        return true;
    }
    if (key.isKeyCode(juce::KeyPress::returnKey))
    {
        controlBar.stopPlayback();
        trackDataModel.setPlayheadPosition(0.0);
        return true;
    }
    if (key.getKeyCode() == 'r' || key.getKeyCode() == 'R')
    {
        controlBar.toggleRecording();
        return true;
    }
    if (key.getKeyCode() == 'c' || key.getKeyCode() == 'C')
    {
        controlBar.toggleCycle();
        return true;
    }
    if (key.getKeyCode() == 'k' || key.getKeyCode() == 'K')
    {
        audioEngine.setMetronomeEnabled(! audioEngine.isMetronomeEnabled());
        return true;
    }

    return false;
}

void MainComponent::handleSpaceTransport()
{
    if (audioEngine.isPlaying())
    {
        controlBar.stopPlayback();
        spaceStopPendingReturn = true;
    }
    else if (spaceStopPendingReturn)
    {
        trackDataModel.setPlayheadPosition(0.0);
        spaceStopPendingReturn = false;
    }
    else
    {
        controlBar.togglePlayback();
    }
}

juce::Result MainComponent::saveProject(const juce::File& file)
{
    const auto result = ProjectSerializer::save(trackDataModel, file);
    if (result.wasOk())
        markProjectSaved();
    return result;
}

juce::Result MainComponent::saveProjectCopy(const juce::File& file) const
{
    return ProjectSerializer::save(trackDataModel, file);
}

juce::Result MainComponent::saveProjectTemplate(const juce::File& file) const
{
    return ProjectSerializer::save(trackDataModel, file);
}

juce::Result MainComponent::loadProject(const juce::File& file, juce::StringArray* missingMediaReferences)
{
    audioEngine.setPlaybackState(false);
    const auto result = ProjectSerializer::load(trackDataModel, pluginHost, file, missingMediaReferences);
    if (result.wasOk())
    {
        audioEngine.prepareActiveEffects();
        selectTrack(0);
        mixerPane.refreshFromModel();
        arrangeWindow.repaint();
        arrangeWindow.requestWaveformPreparation();
        pianoRoll.repaint();
        markProjectSaved();
        if (trackDataModel.getTrackCount() == 0)
            showInitialTrackCreation();
        else
            showWorkspace();
    }
    return result;
}

juce::Result MainComponent::createNewProject()
{
    return createProjectFromTemplate(ProjectTemplate::empty);
}

juce::Result MainComponent::createProjectFromTemplate(ProjectTemplate projectTemplate)
{
    audioEngine.setPlaybackState(false);
    const auto result = trackDataModel.applyProjectState(ProjectTemplates::create(projectTemplate));
    if (result.wasOk())
    {
        selectTrack(0);
        mixerPane.refreshFromModel();
        arrangeWindow.repaint();
        pianoRoll.repaint();
        markProjectSaved();
        if (trackDataModel.getTrackCount() == 0)
            showInitialTrackCreation();
        else
            showWorkspace();
    }
    return result;
}

bool MainComponent::isProjectDirty() const noexcept
{
    return recoveredProjectNeedsSave || trackDataModel.getProjectRevision() != savedProjectRevision;
}

void MainComponent::markProjectSaved() noexcept
{
    savedProjectRevision = trackDataModel.getProjectRevision();
    recoveredProjectNeedsSave = false;
}

void MainComponent::markProjectRecovered() noexcept
{
    recoveredProjectNeedsSave = true;
}

bool MainComponent::undoEdit()
{
    const auto changed = trackDataModel.undo();
    if (changed) { mixerPane.refreshFromModel(); arrangeWindow.repaint(); }
    return changed;
}

bool MainComponent::redoEdit()
{
    const auto changed = trackDataModel.redo();
    if (changed) { mixerPane.refreshFromModel(); arrangeWindow.repaint(); }
    return changed;
}

void MainComponent::requestRecordToggle()
{
    toggleRecording();
}

void MainComponent::setInspectorPanelVisible(bool visible)
{
    inspectorPane.setVisible(visible); controlBar.setInspectorVisible(visible); resized();
}

void MainComponent::setBrowserPanelVisible(bool visible)
{
    assetBrowser.setVisible(visible); controlBar.setBrowserVisible(visible); resized();
    if (visible)
        assetBrowser.focusSearch();
}

void MainComponent::setMixerPanelVisible(bool visible)
{
    mixerPane.setVisible(visible); controlBar.setMixerVisible(visible); resized();
}

bool MainComponent::addTrackFromCommand(TrackType type)
{
    const auto id = trackDataModel.addTrack(type);
    if (! id.isValid())
        return false;
    repairAudioTrackInputAssignments();
    selectTrack(trackDataModel.getTrackIndex(id));
    arrangeWindow.repaint();
    mixerPane.refreshFromModel();
    return true;
}

void MainComponent::importAudioFile(const juce::File& file)
{
    arrangeWindow.importAudioFile(file, getSelectedTrackIndex(), trackDataModel.getPlayheadPosition());
}

juce::Result MainComponent::importMidiFile(const juce::File& file)
{
    std::vector<ImportedMidiTrack> importedTracks;
    const auto parseResult = MidiFileImporter::read(file, trackDataModel.getSampleRate(),
                                                     trackDataModel.getBpm(), importedTracks);
    if (parseResult.failed())
        return parseResult;

    const auto result = trackDataModel.importMidiTracks(importedTracks, trackDataModel.getPlayheadPosition());
    if (result.failed())
        return result;

    selectTrack(static_cast<int>(trackDataModel.getTrackCount() - importedTracks.size()));
    mixerPane.refreshFromModel();
    arrangeWindow.repaint();
    return juce::Result::ok();
}

void MainComponent::requestProjectBounce()
{
    bounceFileChooser = std::make_unique<juce::FileChooser>("Bounce Project", juce::File {}, "*.wav;*.aif;*.aiff;*.flac");
    bounceFileChooser->launchAsync(juce::FileBrowserComponent::saveMode
                                       | juce::FileBrowserComponent::canSelectFiles,
        [safeOwner = juce::Component::SafePointer<MainComponent>(this)](const juce::FileChooser& chooser)
        {
            if (safeOwner == nullptr)
                return;

            auto output = chooser.getResult();
            safeOwner->bounceFileChooser.reset();
            if (output == juce::File {})
                return;

            if (output.getFileExtension().isEmpty())
                output = output.withFileExtension(".wav");

            AudioEngine::OfflineRenderOptions options;
            options.sampleRate = safeOwner->trackDataModel.getSampleRate();
            const auto result = safeOwner->audioEngine.renderOfflineAudio(output, options);
            if (result.failed())
                StudioForgeDialog::showWarning(StudioForgeDialog::fromUtf8("Xu\u1EA5t audio ch\u01B0a ho\u00E0n t\u1EA5t"),
                                               result.getErrorMessage());
        });
}

void MainComponent::selectTrack(int trackIndex)
{
    const auto count = static_cast<int>(trackDataModel.getTrackCount());
    if (count <= 0)
    {
        selectedTrackId = {};
        audioEngine.setFocusedMonitorTrack({});
        arrangeWindow.setSelectedTrack(-1);
        return;
    }
    const auto resolvedIndex = juce::jlimit(0, count - 1, trackIndex);
    selectedTrackId = trackDataModel.getTrackId(static_cast<size_t>(resolvedIndex));
    audioEngine.setFocusedMonitorTrack(selectedTrackId);
    inspectorPane.setSelectedTrack(resolvedIndex);
    arrangeWindow.setSelectedTrack(resolvedIndex);
}

int MainComponent::getSelectedTrackIndex() const noexcept
{
    return selectedTrackId.isValid() ? trackDataModel.getTrackIndex(selectedTrackId) : -1;
}

juce::File MainComponent::createRecordingDestination() const
{
    auto directory = juce::File::getSpecialLocation(juce::File::userDocumentsDirectory)
        .getChildFile("StudioForge Recordings");
    if (! directory.exists() && ! directory.createDirectory())
        return {};
    return directory.getNonexistentChildFile("Recording", ".wav", true);
}

void MainComponent::toggleRecording()
{
    if (audioEngine.isRecording() || audioEngine.isMidiRecording() || recordingCountdownActive)
    {
        if (audioEngine.isRecording())
            audioEngine.stopRecording();
        if (audioEngine.isMidiRecording())
            audioEngine.stopMidiRecording();
        audioEngine.clearRecordingCaptureRange();
        audioEngine.setCountInMetronomeActive(false);
        recordingCountdownActive = false;
        recordingPunchStopSample = -1.0;
        pendingRecordingTrack = -1;
        pendingRecordingDestination = juce::File {};
        pendingAudioRecordingTargets.clear();
        controlBar.setRecordActive(false);
        controlBar.setRecordCountdown(false);
        arrangeWindow.hideRecordingPreview();
        arrangeWindow.repaint();
        return;
    }

    // Record follows the selected channel. The previous "first armed track"
    // fallback made a take appear on an unrelated (often third) track when
    // several tracks were record-ready. Multi-track capture is only used
    // when no audio track is selected.
    const auto selectedTrack = getSelectedTrackIndex();
    const auto armedTrack = trackDataModel.getFirstArmedTrackIndex();
    const auto target = selectedTrack >= 0 ? selectedTrack : armedTrack;
    if (target < 0 || target >= static_cast<int>(trackDataModel.getTrackCount()))
        return;

    const auto type = trackDataModel.getTrack(static_cast<size_t>(target)).type;
    if (type != TrackType::audio && type != TrackType::instrument && type != TrackType::externalMidi)
        return;
    std::vector<AudioEngine::AudioRecordingTarget> audioTargets;
    if (type == TrackType::audio)
    {
        const auto destination = createRecordingDestination();
        if (destination == juce::File {})
            return;
        audioTargets.push_back({ static_cast<size_t>(target), destination });
    }

    if (! audioTargets.empty())
    {
        if (const auto validation = audioEngine.validateRecordingTargets(audioTargets); validation.failed())
        {
            showRecordingFailure(validation);
            return;
        }

        if (audioEngine.isPlaying())
        {
            audioEngine.clearRecordingCaptureRange();
            startAudioRecordingsNow(audioTargets, trackDataModel.getPlayheadPosition());
            return;
        }

        if (trackDataModel.isPunchActive())
        {
            const auto punchIn = trackDataModel.getPunchInSample();
            const auto punchOut = trackDataModel.getPunchOutSample();
            audioEngine.setRecordingCaptureRange(punchIn, punchOut);
            recordingPunchStopSample = punchOut;
            audioEngine.setPlaybackState(true);
            startAudioRecordingsNow(audioTargets, punchIn);
            return;
        }

        audioEngine.clearRecordingCaptureRange();
        if (! countInEnabled)
        {
            startAudioRecordingsNow(audioTargets);
            return;
        }

        const auto samplesPerBeat = trackDataModel.getSampleRate() * 60.0 / trackDataModel.getBpm();
        pendingRecordingStartSample = trackDataModel.getPlayheadPosition()
            + samplesPerBeat * trackDataModel.getTimeSignatureNumerator() * countInBars;
        pendingAudioRecordingTargets = std::move(audioTargets);
        recordingCountdownActive = true;
        audioEngine.setCountInMetronomeActive(true);
        audioEngine.setPlaybackState(true);
        controlBar.setRecordCountdown(true);
        return;
    }

    const auto destination = type == TrackType::audio ? createRecordingDestination() : juce::File {};
    if (type == TrackType::audio && destination == juce::File {})
        return;

    if (audioEngine.isPlaying())
    {
        audioEngine.clearRecordingCaptureRange();
        startRecordingNow(target, destination, trackDataModel.getPlayheadPosition());
        return;
    }

    if (type == TrackType::audio && trackDataModel.isPunchActive())
    {
        const auto punchIn = trackDataModel.getPunchInSample();
        const auto punchOut = trackDataModel.getPunchOutSample();
        audioEngine.setRecordingCaptureRange(punchIn, punchOut);
        recordingPunchStopSample = punchOut;
        audioEngine.setPlaybackState(true);
        startRecordingNow(target, destination, punchIn);
        return;
    }

    audioEngine.clearRecordingCaptureRange();
    if (! countInEnabled)
    {
        startRecordingNow(target, destination);
        return;
    }

    const auto samplesPerBeat = trackDataModel.getSampleRate() * 60.0 / trackDataModel.getBpm();
    pendingRecordingStartSample = trackDataModel.getPlayheadPosition()
        + samplesPerBeat * trackDataModel.getTimeSignatureNumerator() * countInBars;
    pendingRecordingTrack = target;
    pendingRecordingDestination = destination;
    recordingCountdownActive = true;
    audioEngine.setCountInMetronomeActive(true);
    audioEngine.setPlaybackState(true);
    controlBar.setRecordCountdown(true);
}

void MainComponent::startRecordingNow(int trackIndex, const juce::File& destination,
                                      double timelineStartSample)
{
    if (trackIndex < 0 || trackIndex >= static_cast<int>(trackDataModel.getTrackCount()))
        return;
    const auto type = trackDataModel.getTrack(static_cast<size_t>(trackIndex)).type;
    const auto recordingStartSample = timelineStartSample >= 0.0
        ? timelineStartSample : trackDataModel.getPlayheadPosition();
    const auto result = type == TrackType::audio
        ? audioEngine.startRecording(static_cast<size_t>(trackIndex), destination, recordingStartSample)
        : audioEngine.startMidiRecording(static_cast<size_t>(trackIndex));
    if (result.wasOk())
    {
        audioEngine.setPlaybackState(true);
        controlBar.setRecordActive(true);
        arrangeWindow.showRecordingPreview(trackIndex, recordingStartSample);
    }
    else
    {
        showRecordingFailure(result);
    }
}

void MainComponent::startAudioRecordingsNow(const std::vector<AudioEngine::AudioRecordingTarget>& targets,
                                            double timelineStartSample)
{
    if (targets.empty())
        return;

    const auto recordingStartSample = timelineStartSample >= 0.0
        ? timelineStartSample : trackDataModel.getPlayheadPosition();
    const auto result = audioEngine.startRecordings(targets, recordingStartSample);
    if (result.wasOk())
    {
        audioEngine.setPlaybackState(true);
        controlBar.setRecordActive(true);
        arrangeWindow.showRecordingPreview(static_cast<int>(targets.front().trackIndex), recordingStartSample);
    }
    else
    {
        showRecordingFailure(result);
    }
}

void MainComponent::showRecordingFailure(const juce::Result& result) const
{
    StudioForgeDialog::showWarning("Recording unavailable",
                                   "Cannot start recording. " + result.getErrorMessage()
                                       + "\n\nCheck File > Audio Device Settings and each Track Input.");
}

void MainComponent::timerCallback()
{
    // Device scans never run on the audio thread. A one-second refresh gives
    // USB MIDI controllers plug-and-play behaviour without polling per frame.
    if (++midiDeviceRefreshTicks >= 30)
    {
        midiDeviceRefreshTicks = 0;
        audioEngine.refreshMidiInputDevices();
    }

    if (audioEngine.consumeMonitorPermissionsResetRequired())
    {
        trackDataModel.clearTrackMonitorPermissions();
        StudioForgeDialog::showWarning("Monitor safety reset",
                                       "Audio device routing changed. Software monitor routes are off until you enable them again.");
    }

    if (audioEngine.consumeRecordingInterruptedByDeviceDisconnect())
    {
        // Never finalise a take from the device callback. The UI thread owns
        // the orderly close so unplugging an interface cannot leave a writer
        // live against a vanished input stream.
        audioEngine.stopRecording();
        recordingCountdownActive = false;
        recordingPunchStopSample = -1.0;
        pendingRecordingTrack = -1;
        pendingRecordingDestination = juce::File {};
        pendingAudioRecordingTargets.clear();
        controlBar.setRecordActive(false);
        controlBar.setRecordCountdown(false);
        arrangeWindow.hideRecordingPreview();
        arrangeWindow.repaint();
        StudioForgeDialog::showWarning("Audio interface disconnected",
                                       "Recording stopped safely. Reconnect the interface, verify track inputs, then record again.");
    }

    if (audioEngine.isLivePerformanceEnabled())
    {
        const auto key = audioEngine.getLiveKeyResult();
        if (key.revision != 0 && key.revision != appliedLiveKeyRevision)
        {
            audioEngine.applyDetectedKeyToPitchCorrection();
            appliedLiveKeyRevision = key.revision;
        }
    }
    else
    {
        appliedLiveKeyRevision = 0;
    }

    if (recordingCountdownActive && ! audioEngine.isPlaying())
    {
        recordingCountdownActive = false;
        pendingRecordingTrack = -1;
        pendingRecordingDestination = juce::File {};
        pendingAudioRecordingTargets.clear();
        audioEngine.setCountInMetronomeActive(false);
        controlBar.setRecordCountdown(false);
        return;
    }

    if (audioEngine.isRecording() && recordingPunchStopSample >= 0.0
        && trackDataModel.getPlayheadPosition() >= recordingPunchStopSample)
    {
        audioEngine.stopRecording();
        recordingPunchStopSample = -1.0;
        controlBar.setRecordActive(false);
        arrangeWindow.hideRecordingPreview();
        arrangeWindow.repaint();
        return;
    }

    if (! recordingCountdownActive || trackDataModel.getPlayheadPosition() < pendingRecordingStartSample)
        return;

    const auto track = pendingRecordingTrack;
    const auto destination = pendingRecordingDestination;
    auto audioTargets = std::move(pendingAudioRecordingTargets);
    recordingCountdownActive = false;
    audioEngine.setCountInMetronomeActive(false);
    pendingRecordingTrack = -1;
    pendingRecordingDestination = juce::File {};
    controlBar.setRecordCountdown(false);
    if (! audioTargets.empty())
        startAudioRecordingsNow(audioTargets);
    else if (track >= 0)
        startRecordingNow(track, destination);
}

void MainComponent::setWorkspaceTrackHeight(int height)
{
    trackDataModel.setTrackHeight(height);
    arrangeWindow.repaint();
}

void MainComponent::paint(juce::Graphics& g)
{
    g.fillAll(StudioForgeTheme::workspaceBackground);
    auto glow = juce::ColourGradient(StudioForgeTheme::accentBlue, 0.0f, 0.0f,
                                     StudioForgeTheme::accentCyan, getWidth(), 0.0f, false);
    g.setGradientFill(glow);
    g.fillRect(0.0f, 0.0f, static_cast<float>(getWidth()), 2.0f);
}

void MainComponent::resized()
{
    auto area = getLocalBounds();
    controlBar.setBounds(area.removeFromTop(64));

    // Dock panes from a bounded budget so opening both lower editors never
    // collapses the arrange workspace or overlaps controls on smaller screens.
    const auto dockBudget = juce::jmax(0, area.getHeight() - 220);
    const auto requestedDockHeight = (mixerPane.isVisible() ? 270 : 0)
                                   + (pianoRoll.isVisible() ? 250 : 0);
    const auto dockScale = requestedDockHeight > 0
        ? juce::jmin(1.0f, static_cast<float>(dockBudget) / static_cast<float>(requestedDockHeight)) : 0.0f;
    if (mixerPane.isVisible())
        mixerPane.setBounds(area.removeFromBottom(juce::roundToInt(270.0f * dockScale)));
    if (pianoRoll.isVisible())
        pianoRoll.setBounds(area.removeFromBottom(juce::roundToInt(250.0f * dockScale)));

    const auto sideBudget = juce::jmax(0, area.getWidth() - 440);
    // Keep the Inspector's channel strips at a stable working width. A wide
    // display should reveal more arrangement space, not stretch plugin slots
    // and mixer controls into a different visual system.
    const auto inspectorTargetWidth = juce::jlimit(250, 310,
                                                    juce::roundToInt(static_cast<float>(getWidth()) * 0.175f));
    const auto browserTargetWidth = juce::jlimit(236, 266, juce::roundToInt(static_cast<float>(getWidth()) * 0.156f));
    const auto requestedSideWidth = (inspectorPane.isVisible() ? inspectorTargetWidth : 0)
                                  + (assetBrowser.isVisible() ? browserTargetWidth : 0);
    const auto sideScale = requestedSideWidth > 0
        ? juce::jmin(1.0f, static_cast<float>(sideBudget) / static_cast<float>(requestedSideWidth)) : 0.0f;
    if (inspectorPane.isVisible())
        inspectorPane.setBounds(area.removeFromLeft(juce::roundToInt(static_cast<float>(inspectorTargetWidth) * sideScale)));
    if (assetBrowser.isVisible())
        assetBrowser.setBounds(area.removeFromRight(juce::roundToInt(static_cast<float>(browserTargetWidth) * sideScale)));

    arrangeWindow.setBounds(area);
    startupWorkflow.setBounds(getLocalBounds());
}
