#pragma once

#include <algorithm>
#include <cmath>

// Pure logical-coordinate hit testing for audio regions.  TimelineGrid owns
// conversion from samples/scroll/zoom to these component-local coordinates.
enum class AudioRegionMouseZone { none, move, leftTrim, rightTrim, fadeIn, fadeOut };
enum class AudioRegionInteractionPhase { idle, hover, pressed, dragging, committing, cancelled };

struct AudioRegionBounds
{
    float x = 0.0f;
    float y = 0.0f;
    float width = 0.0f;
    float height = 0.0f;
};

inline AudioRegionMouseZone detectAudioRegionMouseZone(float mouseX, float mouseY,
                                                        const AudioRegionBounds& bounds,
                                                        float edgeThreshold = 8.0f) noexcept
{
    if (! std::isfinite(mouseX) || ! std::isfinite(mouseY) || bounds.width <= 0.0f || bounds.height <= 0.0f)
        return AudioRegionMouseZone::none;

    const auto right = bounds.x + bounds.width;
    const auto bottom = bounds.y + bounds.height;
    if (mouseX < bounds.x || mouseX > right || mouseY < bounds.y || mouseY > bottom)
        return AudioRegionMouseZone::none;

    // Short regions never have ambiguous edge ownership: their nearest edge
    // wins, while the upper/lower half still determines fade versus trim.
    const auto edge = std::max(1.0f, std::min(edgeThreshold, bounds.width * 0.5f));
    const auto left = std::abs(mouseX - bounds.x) <= edge;
    const auto rightEdge = std::abs(mouseX - right) <= edge;
    const auto useLeft = left && (! rightEdge || std::abs(mouseX - bounds.x) <= std::abs(mouseX - right));
    // Resize has the full-height edge target. This is substantially more
    // reliable than splitting a small region vertically, and guarantees an
    // edge never accidentally becomes a region move. Fade is an explicit
    // modifier gesture in TimelineGrid.
    if (useLeft) return AudioRegionMouseZone::leftTrim;
    if (rightEdge) return AudioRegionMouseZone::rightTrim;
    return AudioRegionMouseZone::move;
}

inline bool audioRegionDragThresholdExceeded(float downX, float downY, float currentX, float currentY,
                                             float threshold = 4.0f) noexcept
{
    return std::hypot(currentX - downX, currentY - downY) >= threshold;
}
