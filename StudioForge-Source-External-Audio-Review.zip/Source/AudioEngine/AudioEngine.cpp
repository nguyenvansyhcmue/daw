#include "AudioEngine.h"
#include "GainUtilityProcessor.h"

#include <algorithm>
#include <cmath>

namespace
{
constexpr int livePluginLatencyBudgetSamples = 64;

int preferredLiveBufferSize(const juce::Array<int>& availableSizes, int currentSize)
{
    // The production live policy is 64 samples when the device supports it.
    // Do not auto-promote to 32: stability under a crowded live session is
    // more valuable than a small theoretical latency reduction.
    if (currentSize == 64 && availableSizes.contains(currentSize))
        return currentSize;
    for (const auto preferred : { 64, 128, 256 })
        if (availableSizes.contains(preferred))
            return preferred;

    auto smallest = currentSize;
    for (const auto size : availableSizes)
        if (smallest <= 0 || size < smallest)
            smallest = size;
    return smallest;
}

juce::File getAudioDeviceStateFile()
{
    auto settingsFolder = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                              .getChildFile("StudioForge");
    settingsFolder.createDirectory();
    return settingsFolder.getChildFile("audio-device.xml");
}

float peakForChannel(const juce::AudioBuffer<float>& buffer, int channel, int numSamples) noexcept
{
    if (channel >= buffer.getNumChannels()) return 0.0f;
    auto peak = 0.0f;
    const auto* samples = buffer.getReadPointer(channel);
    for (int sample = 0; sample < numSamples; ++sample)
        peak = juce::jmax(peak, std::abs(samples[sample]));
    return peak;
}

std::unique_ptr<juce::AudioFormat> createOfflineFormat(const juce::File& destination)
{
    const auto extension = destination.getFileExtension().toLowerCase();
    if (extension == ".wav") return std::make_unique<juce::WavAudioFormat>();
    if (extension == ".aif" || extension == ".aiff") return std::make_unique<juce::AiffAudioFormat>();
    if (extension == ".flac") return std::make_unique<juce::FlacAudioFormat>();
    return {};
}
}

// This is a deliberately fixed-size, single-producer/single-consumer bridge.
// The main device callback is its only writer and the virtual device callback
// is its only reader.  Keeping the storage here (rather than in AudioBuffer)
// makes both callback paths allocation-free and independent of their block
// sizes/clock cadence.
class AudioEngine::StreamOutputBridge final : public juce::AudioIODeviceCallback
{
public:
    static constexpr uint64_t capacityFrames = 1u << 16;
    static constexpr uint64_t frameMask = capacityFrames - 1;

    explicit StreamOutputBridge(AudioEngine& engineIn) : engine(engineIn) {}

    void write(const juce::AudioBuffer<float>& source, int numSamples) noexcept
    {
        if (numSamples <= 0 || source.getNumChannels() == 0) return;

        const auto read = readFrame.load(std::memory_order_acquire);
        auto write = writeFrame.load(std::memory_order_relaxed);
        const auto available = capacityFrames - (write - read);
        const auto count = juce::jmin<uint64_t>(static_cast<uint64_t>(numSamples), available);
        const auto* left = source.getReadPointer(0);
        const auto* right = source.getReadPointer(source.getNumChannels() > 1 ? 1 : 0);
        for (uint64_t sample = 0; sample < count; ++sample)
        {
            const auto destination = ((write + sample) & frameMask) * 2;
            frames[static_cast<size_t>(destination)] = left[sample];
            frames[static_cast<size_t>(destination + 1)] = right[sample];
        }
        write += count;
        writeFrame.store(write, std::memory_order_release);
    }

    void audioDeviceAboutToStart(juce::AudioIODevice*) override
    {
        started.store(true, std::memory_order_release);
    }

    void audioDeviceStopped() override
    {
        started.store(false, std::memory_order_release);
        // This also covers a virtual device disappearing while selected.  The
        // message thread can retain the selection, but UI state immediately
        // becomes "Not configured" until a successful reopen.
        engine.streamOutputConfigured.store(false, std::memory_order_release);
    }

    void audioDeviceIOCallbackWithContext(const float* const*, int,
                                          float* const* output, int outputChannels,
                                          int numSamples,
                                          const juce::AudioIODeviceCallbackContext&) override
    {
        if (outputChannels <= 0 || numSamples <= 0) return;

        auto read = readFrame.load(std::memory_order_relaxed);
        const auto write = writeFrame.load(std::memory_order_acquire);
        const auto count = juce::jmin<uint64_t>(static_cast<uint64_t>(numSamples), write - read);
        const auto muted = engine.streamMuted.load(std::memory_order_acquire);
        auto peak = 0.0f;
        for (int sample = 0; sample < numSamples; ++sample)
        {
            float left = 0.0f, right = 0.0f;
            if (static_cast<uint64_t>(sample) < count)
            {
                const auto source = ((read + static_cast<uint64_t>(sample)) & frameMask) * 2;
                left = frames[static_cast<size_t>(source)];
                right = frames[static_cast<size_t>(source + 1)];
            }
            if (muted) left = right = 0.0f;
            if (output[0] != nullptr) output[0][sample] = left;
            if (outputChannels > 1 && output[1] != nullptr) output[1][sample] = right;
            for (int channel = 2; channel < outputChannels; ++channel)
                if (output[channel] != nullptr) output[channel][sample] = 0.0f;
            peak = juce::jmax(peak, juce::jmax(std::abs(left), std::abs(right)));
        }
        read += count;
        readFrame.store(read, std::memory_order_release);
        engine.streamPeak.store(peak, std::memory_order_relaxed);
    }

    bool hasStarted() const noexcept { return started.load(std::memory_order_acquire); }

private:
    AudioEngine& engine;
    alignas(64) std::array<float, capacityFrames * 2> frames {};
    alignas(64) std::atomic<uint64_t> readFrame { 0 };
    alignas(64) std::atomic<uint64_t> writeFrame { 0 };
    std::atomic<bool> started { false };
};

AudioEngine::AudioEngine(TrackDataModel* model)
    : dataModel(model)
{
    for (auto& callbackChannel : callbackInputByPhysicalChannel)
        callbackChannel.store(-1, std::memory_order_relaxed);
    for (auto& callbackChannel : callbackOutputByPhysicalChannel)
        callbackChannel.store(-1, std::memory_order_relaxed);
    graph.addNode(std::make_unique<GainNode>(1.0f));
    publishMasterFxRack(std::make_unique<TrackDataModel::FxRackSnapshot>());
    if (dataModel != nullptr) recordingSession = std::make_unique<RecordingSession>(*dataModel);
}

AudioEngine::~AudioEngine()
{
    shutdown();
}

void AudioEngine::initialise()
{
    const auto stateFile = getAudioDeviceStateFile();
    const auto savedState = stateFile.existsAsFile() ? juce::parseXML(stateFile) : nullptr;
    deviceManager.initialise(2, 2, savedState.get(), true);
    if (savedState == nullptr)
        enableAllAvailableInputsOnFirstLaunch();
    deviceManager.addAudioCallback(this);
    deviceManager.addMidiInputDeviceCallback({}, this);
    refreshMidiInputDevices();
    if (savedState != nullptr)
        setMidiOutputDevice(savedState->getStringAttribute("midiOutputDeviceIdentifier"));
    setMasterGain(1.0f);
    // Monitoring is deliberately opt-in. Opening a project must never route a
    // microphone to speakers before the performer explicitly enables LIVE.
    // Recording capture and input meters remain available while LIVE is off.
    setLivePerformanceEnabled(false);
    optimiseDeviceForLivePerformance();
}

void AudioEngine::shutdown()
{
    if (recordingSession != nullptr) recordingSession->stop();
    closeStreamOutputDevice();
    deviceManager.removeMidiInputDeviceCallback({}, this);
    for (const auto& identifier : managedMidiInputIdentifiers)
        deviceManager.setMidiInputDeviceEnabled(identifier, false);
    managedMidiInputIdentifiers.clear();
    deviceManager.removeAudioCallback(this);
    deviceManager.closeAudioDevice();
    setMidiOutputDevice({});
    processingBuffer.clear();
}

void AudioEngine::setMasterGain(float gain) noexcept
{
    masterGain.store(juce::jlimit(0.0f, 2.0f, gain));
    graph.setMasterGain(masterGain.load());
}

float AudioEngine::getMasterGain() const noexcept
{
    return masterGain.load();
}

void AudioEngine::setTempo(double newTempo) noexcept
{
    if (dataModel != nullptr)
        dataModel->setBpm(newTempo);
}

void AudioEngine::saveAudioDeviceState() const
{
    const auto state = deviceManager.createStateXml();
    if (state != nullptr)
    {
        state->setAttribute("midiOutputDeviceIdentifier", midiOutputDeviceIdentifier);
        state->writeTo(getAudioDeviceStateFile());
    }
}

juce::Array<juce::MidiDeviceInfo> AudioEngine::getAvailableMidiOutputDevices() const
{
    return juce::MidiOutput::getAvailableDevices();
}

juce::String AudioEngine::getMidiOutputDeviceIdentifier() const
{
    return midiOutputDeviceIdentifier;
}

juce::Result AudioEngine::setMidiOutputDevice(const juce::String& identifier)
{
    auto replacement = identifier.isEmpty() ? std::unique_ptr<juce::MidiOutput>() : juce::MidiOutput::openDevice(identifier);
    if (! identifier.isEmpty() && replacement == nullptr)
        return juce::Result::fail("Cannot open the selected MIDI output device");

    auto previous = std::move(midiOutput);
    midiOutput = std::move(replacement);
    midiOutputDeviceIdentifier = identifier;
    publishedMidiOutput.store(midiOutput.get(), std::memory_order_release);
    while (midiOutputCallbackUsers.load(std::memory_order_acquire) != 0)
        juce::Thread::sleep(1);
    return juce::Result::ok();
}

void AudioEngine::setMetronomeEnabled(bool enabled) noexcept
{
    metronomeEnabled.store(enabled, std::memory_order_release);
}

bool AudioEngine::isMetronomeEnabled() const noexcept
{
    return metronomeEnabled.load(std::memory_order_acquire);
}

void AudioEngine::setCountInMetronomeActive(bool active) noexcept
{
    countInMetronomeActive.store(active, std::memory_order_release);
}

void AudioEngine::setLivePerformanceEnabled(bool enabled) noexcept
{
    // Compatibility bridge for callers outside the workspace controller.
    workspaceMode.store(enabled ? WorkspaceMode::stage : WorkspaceMode::studio, std::memory_order_release);
    // LIVE is intended for performers first. Keep normal mixing intact outside
    // this mode, but avoid reported look-ahead/linear-phase delays while live.
    liveLowLatencyProtectionEnabled.store(enabled, std::memory_order_release);
}

bool AudioEngine::isLivePerformanceEnabled() const noexcept
{
    return getWorkspaceMode() != WorkspaceMode::studio;
}

WorkspaceMode AudioEngine::getWorkspaceMode() const noexcept
{
    return workspaceMode.load(std::memory_order_acquire);
}

juce::Result AudioEngine::validateWorkspaceProfile(const WorkspaceProfile& profile) const
{
    if (profile.mode == WorkspaceMode::studio) return juce::Result::ok();
    if (deviceManager.getCurrentAudioDevice() == nullptr)
        return juce::Result::fail("No active audio device for live workspace");
    return juce::Result::ok();
}

juce::Result AudioEngine::applyWorkspaceProfile(const WorkspaceProfile& profile)
{
    if (const auto validation = validateWorkspaceProfile(profile); validation.failed())
        return validation;
    // Modes are usable presets, not merely a different layout. A track which
    // is already explicitly In/Auto is brought live with a route guaranteed
    // to exist on the active interface. Tracks configured Off stay Off.
    // Master is the universal fallback: a two-output interface such as a
    // Scarlett Solo cannot satisfy a 3/4 CUE route and must never become
    // silently inaudible just because the user selected STAGE or STREAM.
    if (dataModel != nullptr)
    {
        const auto cueAvailable = callbackOutputForPhysicalChannel(2) >= 0
            && callbackOutputForPhysicalChannel(3) >= 0;
        const auto destination = profile.mode == WorkspaceMode::stage && cueAvailable
            ? MonitorDestination::cue : MonitorDestination::master;
        const auto deviceName = deviceManager.getCurrentAudioDevice() != nullptr
            ? deviceManager.getCurrentAudioDevice()->getName().toLowerCase() : juce::String {};
        // STUDIO is a working audio mode too: selecting it must not turn a
        // configured microphone into a meter-only input. All modes use the
        // same available-route fallback. Known built-in/speaker paths remain
        // safe-off because they are the high-probability feedback case.
        if (destination == MonitorDestination::master
            && (deviceName.contains("built-in") || deviceName.contains("speaker")))
            dataModel->clearTrackMonitorPermissions();
        else
            dataModel->activateConfiguredMonitorRoutes(destination);
    }
    const auto previousMode = getWorkspaceMode();
    if (previousMode == WorkspaceMode::studio && profile.mode != WorkspaceMode::studio)
        if (auto* device = deviceManager.getCurrentAudioDevice(); device != nullptr)
            studioBufferSizeBeforeLive = device->getCurrentBufferSizeSamples();

    liveLowLatencyProtectionEnabled.store(profile.protectsLivePluginLatency(), std::memory_order_release);
    if (profile.mode == WorkspaceMode::studio && studioBufferSizeBeforeLive > 0)
    {
        auto setup = deviceManager.getAudioDeviceSetup();
        if (setup.bufferSize != studioBufferSizeBeforeLive)
        {
            setup.bufferSize = studioBufferSizeBeforeLive;
            if (const auto error = deviceManager.setAudioDeviceSetup(setup, true); error.isNotEmpty())
                return juce::Result::fail(error);
        }
    }
    else if (profile.latency == LatencyPolicy::preferLowLatency)
    {
        if (const auto result = optimiseDeviceForLivePerformance(); result.failed()) return result;
    }
    workspaceMode.store(profile.mode, std::memory_order_release);
    return juce::Result::ok();
}

void AudioEngine::setPanicMute(bool enabled) noexcept { panicMuteEnabled.store(enabled, std::memory_order_release); }
bool AudioEngine::isPanicMuteEnabled() const noexcept { return panicMuteEnabled.load(std::memory_order_acquire); }
void AudioEngine::setStreamMuted(bool muted) noexcept { streamMuted.store(muted, std::memory_order_release); }
bool AudioEngine::isStreamMuted() const noexcept { return streamMuted.load(std::memory_order_acquire); }
float AudioEngine::getStreamPeak() const noexcept { return streamPeak.load(std::memory_order_relaxed); }

juce::StringArray AudioEngine::getAvailableAudioOutputDevices() const
{
    juce::StringArray names;
    if (auto* type = deviceManager.getCurrentDeviceTypeObject(); type != nullptr)
        names = type->getDeviceNames(false);
    return names;
}

juce::Result AudioEngine::selectStreamOutputDevice(const juce::String& deviceName)
{
    // A selection becomes connected only after the second device has started
    // its callback.  This avoids showing a false-positive status for an
    // unplugged/permission-denied virtual device.
    closeStreamOutputDevice();
    if (deviceName.isEmpty())
    {
        streamOutputDeviceName.clear();
        return juce::Result::ok();
    }
    if (! getAvailableAudioOutputDevices().contains(deviceName))
        return juce::Result::fail("Selected stream output device is unavailable");
    streamOutputDeviceName = deviceName;
    return openStreamOutputDevice(deviceName);
}

juce::String AudioEngine::getStreamOutputDevice() const { return streamOutputDeviceName; }
bool AudioEngine::isStreamOutputConfigured() const noexcept { return streamOutputConfigured.load(std::memory_order_acquire); }

juce::Result AudioEngine::validateMonitorRoute(size_t trackIndex, MonitorDestination destination,
                                               bool allowSpeakerRisk) const
{
    if (dataModel == nullptr || trackIndex >= dataModel->getTrackCount())
        return juce::Result::fail("Monitor track is unavailable");
    if (destination == MonitorDestination::off)
        return juce::Result::ok();
    auto* device = deviceManager.getCurrentAudioDevice();
    if (device == nullptr)
        return juce::Result::fail("No active audio output device");
    if (destination == MonitorDestination::cue
        && (callbackOutputForPhysicalChannel(2) < 0 || callbackOutputForPhysicalChannel(3) < 0))
        return juce::Result::fail("Cue requires physical output channels 3/4");
    if (destination == MonitorDestination::streamOnly)
    {
        if (! isStreamOutputConfigured())
            return juce::Result::fail("Stream Output is not connected");
        // A single CoreAudio device used as both the main input path and the
        // virtual stream sink is an immediate digital-loop risk. Aggregate
        // topology needs platform IDs to refine this further, so it remains
        // conservatively blocked here.
        if (device->getName() == streamOutputDeviceName)
            return juce::Result::fail("Potential feedback loop: input device is the Stream Output device");
    }
    if (destination == MonitorDestination::master && ! allowSpeakerRisk)
    {
        const auto name = device->getName().toLowerCase();
        if (name.contains("built-in") || name.contains("speaker"))
            return juce::Result::fail("Microphone monitoring through speakers may cause feedback");
    }
    return juce::Result::ok();
}

juce::Result AudioEngine::enableTrackMonitor(size_t trackIndex, MonitorDestination destination,
                                             bool allowSpeakerRisk)
{
    if (const auto validation = validateMonitorRoute(trackIndex, destination, allowSpeakerRisk); validation.failed())
        return validation;
    dataModel->setTrackMonitorDestination(trackIndex, destination);
    dataModel->setTrackMonitorPermission(trackIndex, destination != MonitorDestination::off);
    configureDirectMonitor(trackIndex, destination == MonitorDestination::master);
    return juce::Result::ok();
}

void AudioEngine::disableTrackMonitor(size_t trackIndex) noexcept
{
    if (dataModel != nullptr)
    {
        dataModel->setTrackMonitorPermission(trackIndex, false);
        if (dataModel->getTrackId(trackIndex).value == directMonitorTrackId.load(std::memory_order_acquire))
            configureDirectMonitor(trackIndex, false);
    }
}

void AudioEngine::configureDirectMonitor(size_t trackIndex, bool enabled) noexcept
{
    if (! enabled || dataModel == nullptr || trackIndex >= dataModel->getTrackCount())
    {
        directMonitorTrackId.store(0, std::memory_order_release);
        directMonitorPhysicalInput.store(-1, std::memory_order_release);
        return;
    }
    const auto& track = dataModel->getTrack(trackIndex);
    directMonitorPhysicalInput.store(track.inputChannel.load(std::memory_order_relaxed), std::memory_order_release);
    directMonitorTrackId.store(track.id.value, std::memory_order_release);
}

juce::Result AudioEngine::openStreamOutputDevice(const juce::String& deviceName)
{
    auto* type = deviceManager.getCurrentDeviceTypeObject();
    auto* mainDevice = deviceManager.getCurrentAudioDevice();
    if (type == nullptr || mainDevice == nullptr)
        return juce::Result::fail("No active audio device type for stream output");

    std::unique_ptr<juce::AudioIODevice> device(type->createDevice(deviceName, {}));
    if (device == nullptr)
        return juce::Result::fail("Cannot create the selected stream output device");

    juce::BigInteger outputChannels;
    const auto channelCount = device->getOutputChannelNames().size();
    if (channelCount <= 0)
        return juce::Result::fail("Selected stream output device has no output channels");
    outputChannels.setRange(0, juce::jmin(2, channelCount), true);

    auto sampleRate = mainDevice->getCurrentSampleRate();
    const auto sampleRates = device->getAvailableSampleRates();
    if (! sampleRates.isEmpty() && ! sampleRates.contains(sampleRate))
        sampleRate = sampleRates[0];
    auto bufferSize = mainDevice->getCurrentBufferSizeSamples();
    const auto bufferSizes = device->getAvailableBufferSizes();
    if (! bufferSizes.isEmpty() && ! bufferSizes.contains(bufferSize))
        bufferSize = bufferSizes[0];

    if (const auto error = device->open({}, outputChannels, sampleRate, bufferSize); error.isNotEmpty())
        return juce::Result::fail("Cannot open stream output device: " + error);

    auto bridge = std::make_unique<StreamOutputBridge>(*this);
    device->start(bridge.get());
    if (! bridge->hasStarted())
    {
        device->close();
        return juce::Result::fail("Stream output device did not start its audio callback");
    }

    streamOutputBridge = std::move(bridge);
    streamOutputDevice = std::move(device);
    publishedStreamOutputBridge.store(streamOutputBridge.get(), std::memory_order_release);
    streamOutputConfigured.store(true, std::memory_order_release);
    return juce::Result::ok();
}

void AudioEngine::closeStreamOutputDevice()
{
    streamOutputConfigured.store(false, std::memory_order_release);
    publishedStreamOutputBridge.store(nullptr, std::memory_order_release);
    if (streamOutputDevice != nullptr)
    {
        streamOutputDevice->stop();
        streamOutputDevice->close();
    }
    streamOutputDevice.reset();
    if (streamOutputBridge != nullptr)
        retiredStreamOutputBridges.push_back(std::move(streamOutputBridge));
    streamPeak.store(0.0f, std::memory_order_relaxed);
}

void AudioEngine::publishStreamOutput(const juce::AudioBuffer<float>& source, int numSamples) noexcept
{
    if (auto* bridge = publishedStreamOutputBridge.load(std::memory_order_acquire); bridge != nullptr)
        bridge->write(source, numSamples);
}

bool AudioEngine::isLiveLowLatencyProtectionEnabled() const noexcept
{
    return liveLowLatencyProtectionEnabled.load(std::memory_order_acquire);
}

void AudioEngine::setFocusedMonitorTrack(TrackId track) noexcept
{
    focusedMonitorTrackId.store(track.value, std::memory_order_release);
}

juce::Result AudioEngine::optimiseDeviceForLivePerformance()
{
    auto* device = deviceManager.getCurrentAudioDevice();
    if (device == nullptr)
        return juce::Result::fail("No active audio device");

    const auto targetBufferSize = preferredLiveBufferSize(device->getAvailableBufferSizes(),
                                                           device->getCurrentBufferSizeSamples());
    if (targetBufferSize <= 0 || targetBufferSize == device->getCurrentBufferSizeSamples())
        return juce::Result::ok();

    auto setup = deviceManager.getAudioDeviceSetup();
    setup.bufferSize = targetBufferSize;
    if (const auto error = deviceManager.setAudioDeviceSetup(setup, true); error.isNotEmpty())
        return juce::Result::fail(error);

    prepareActiveEffects();
    return juce::Result::ok();
}

juce::Result AudioEngine::startRecording(size_t trackIndex, const juce::File& destination,
                                         double timelineStartSample)
{
    return startRecordings({ { trackIndex, destination } }, timelineStartSample);
}

juce::Result AudioEngine::startRecordings(const std::vector<AudioRecordingTarget>& targets,
                                          double timelineStartSample)
{
    if (const auto validation = validateRecordingTargets(targets); validation.failed())
        return validation;

    auto* device = deviceManager.getCurrentAudioDevice();
    const auto sampleRate = device != nullptr ? device->getCurrentSampleRate() : dataModel->getSampleRate();
    const auto blockSize = device != nullptr ? device->getCurrentBufferSizeSamples() : processingBuffer.getNumSamples();

    std::vector<RecordingSession::TrackTarget> recordingTargets;
    recordingTargets.reserve(targets.size());
    for (const auto& target : targets)
    {
        const auto physicalInputChannel = dataModel->getTrack(target.trackIndex).inputChannel.load(std::memory_order_relaxed);
        const auto inputChannelCount = dataModel->getTrack(target.trackIndex).inputChannelCount.load(std::memory_order_relaxed);
        const auto callbackInputChannel = activeCallbackInputCount.load(std::memory_order_acquire) > 0
            ? callbackInputForPhysicalChannel(physicalInputChannel) : physicalInputChannel;
        recordingTargets.push_back({ target.trackIndex, target.destination, callbackInputChannel, inputChannelCount });
    }

    const auto startSample = timelineStartSample >= 0.0 ? timelineStartSample : dataModel->getPlayheadPosition();
    const auto result = recordingSession->startMany(recordingTargets, startSample, sampleRate, blockSize);
    if (result.wasOk())
        for (const auto& target : targets)
            dataModel->setTrackArmed(target.trackIndex, true);
    return result;
}

juce::Result AudioEngine::validateRecordingTargets(const std::vector<AudioRecordingTarget>& targets) const
{
    if (recordingSession == nullptr || dataModel == nullptr)
        return juce::Result::fail("Audio engine has no project model");
    if (targets.empty())
        return juce::Result::fail("Select at least one audio track to record");

    const auto* device = deviceManager.getCurrentAudioDevice();
    // Direct callback hosts (offline validation and automated tests) do not
    // register their device with AudioDeviceManager. Their prepared realtime
    // buffers still describe a valid input configuration.
    const auto hasPhysicalInputMap = activeCallbackInputCount.load(std::memory_order_acquire) > 0;
    const auto inputChannels = hasPhysicalInputMap ? activeCallbackInputCount.load(std::memory_order_acquire)
                                                   : processingBuffer.getNumChannels();
    if (inputChannels <= 0 || processingBuffer.getNumSamples() <= 0)
        return juce::Result::fail("Enable at least one audio input before recording");

    for (const auto& target : targets)
    {
        if (target.trackIndex >= dataModel->getTrackCount()
            || dataModel->getTrack(target.trackIndex).type != TrackType::audio)
            return juce::Result::fail("Recording requires audio tracks");

        const auto& track = dataModel->getTrack(target.trackIndex);
        const auto inputChannel = track.inputChannel.load(std::memory_order_relaxed);
        const auto inputChannelCount = track.inputChannelCount.load(std::memory_order_relaxed);
        if (inputChannel < 0 || inputChannelCount < 1 || inputChannelCount > 2
            || (hasPhysicalInputMap && ! isPhysicalInputRouteAvailable(inputChannel, inputChannelCount))
            || (! hasPhysicalInputMap && inputChannel + inputChannelCount > inputChannels))
            return juce::Result::fail("Track input is not enabled on the selected audio device");
    }
    return juce::Result::ok();
}

juce::Result AudioEngine::stopRecording()
{
    if (recordingSession == nullptr) return juce::Result::ok();
    clearRecordingCaptureRange();
    const auto result = recordingSession->stop();
    if (dataModel != nullptr)
        for (size_t index = 0; index < dataModel->getTrackCount(); ++index) dataModel->setTrackArmed(index, false);
    return result;
}
bool AudioEngine::isRecording() const noexcept { return recordingSession != nullptr && recordingSession->isRecording(); }

bool AudioEngine::consumeRecordingInterruptedByDeviceDisconnect() noexcept
{
    return recordingInterruptedByDeviceDisconnect.exchange(false, std::memory_order_acq_rel);
}

bool AudioEngine::consumeMonitorPermissionsResetRequired() noexcept
{
    return monitorPermissionsResetRequired.exchange(false, std::memory_order_acq_rel);
}

juce::Result AudioEngine::startMidiRecording(size_t trackIndex)
{
    if (dataModel == nullptr || trackIndex >= dataModel->getTrackCount())
        return juce::Result::fail("MIDI recording track is invalid");
    const auto& track = dataModel->getTrack(trackIndex);
    if (track.type != TrackType::instrument && track.type != TrackType::externalMidi)
        return juce::Result::fail("MIDI recording requires an instrument or external MIDI track");
    if (midiRecordingActive.load(std::memory_order_acquire))
        return juce::Result::fail("MIDI recording is already active");

    recordedMidiFifo.reset();
    droppedMidiRecordingEvents.store(0, std::memory_order_relaxed);
    midiRecordingTrack = track.id;
    midiRecordingStartSample = dataModel->getPlayheadPosition();
    midiRecordingActive.store(true, std::memory_order_release);
    dataModel->setTrackArmed(trackIndex, true);
    return juce::Result::ok();
}

MidiClipId AudioEngine::stopMidiRecording()
{
    if (! midiRecordingActive.exchange(false, std::memory_order_acq_rel) || dataModel == nullptr)
        return {};

    while (midiRecordingCallbackUsers.load(std::memory_order_acquire) != 0)
        juce::Thread::sleep(1);

    std::vector<RecordedMidiEvent> events;
    events.reserve(static_cast<size_t>(recordedMidiFifo.getNumReady()));
    int start1 = 0, size1 = 0, start2 = 0, size2 = 0;
    recordedMidiFifo.prepareToRead(recordedMidiCapacity, start1, size1, start2, size2);
    const auto copyRange = [this, &events] (int start, int count)
    {
        for (int offset = 0; offset < count; ++offset)
            events.push_back(recordedMidiEvents[static_cast<size_t>(start + offset)]);
    };
    copyRange(start1, size1);
    copyRange(start2, size2);
    recordedMidiFifo.finishedRead(size1 + size2);
    if (events.empty())
        return {};

    struct OpenNote { int pitch; int channel; float velocity; double start; };
    std::vector<OpenNote> openNotes;
    std::vector<MidiNoteEvent> notes;
    const auto stopSample = dataModel->getPlayheadPosition();
    for (const auto& event : events)
    {
        if (event.noteOn)
        {
            openNotes.push_back({ event.pitch, event.channel, event.velocity, event.samplePosition });
            continue;
        }

        const auto match = std::find_if(openNotes.rbegin(), openNotes.rend(), [&event] (const OpenNote& open)
        {
            return open.pitch == event.pitch && open.channel == event.channel;
        });
        if (match == openNotes.rend())
            continue;
        notes.push_back({ {}, match->pitch, match->velocity,
                          match->start - midiRecordingStartSample,
                          event.samplePosition - match->start, match->channel });
        openNotes.erase(std::next(match).base());
    }
    for (const auto& open : openNotes)
        notes.push_back({ {}, open.pitch, open.velocity, open.start - midiRecordingStartSample,
                          stopSample - open.start, open.channel });

    return dataModel->addMidiRecording(midiRecordingTrack, midiRecordingStartSample, std::move(notes));
}

bool AudioEngine::isMidiRecording() const noexcept
{
    return midiRecordingActive.load(std::memory_order_acquire);
}

void AudioEngine::setRecordingCaptureRange(double startSample, double endSample) noexcept
{
    const auto start = juce::jmax(0.0, juce::jmin(startSample, endSample));
    const auto end = juce::jmax(0.0, juce::jmax(startSample, endSample));
    recordingCaptureStartSample.store(start, std::memory_order_release);
    recordingCaptureEndSample.store(end, std::memory_order_release);
    recordingCaptureRangeActive.store(end > start, std::memory_order_release);
}

void AudioEngine::clearRecordingCaptureRange() noexcept
{
    recordingCaptureRangeActive.store(false, std::memory_order_release);
}

juce::Result AudioEngine::renderOfflineWav(const juce::File& destination, double sampleRate,
                                           int blockSize, bool useCycle)
{
    OfflineRenderOptions options;
    options.sampleRate = sampleRate;
    options.blockSize = blockSize;
    options.useCycle = useCycle;
    return renderOfflineAudio(destination.withFileExtension(".wav"), options);
}

juce::Result AudioEngine::renderOfflineAudio(const juce::File& destination,
                                             const OfflineRenderOptions& options)
{
    if (dataModel == nullptr || options.sampleRate <= 0.0 || options.blockSize <= 0)
        return juce::Result::fail("Offline render configuration is invalid");
    if (isRecording()) return juce::Result::fail("Stop recording before offline render");
    auto format = createOfflineFormat(destination);
    if (format == nullptr)
        return juce::Result::fail("Unsupported bounce format. Choose WAV, AIFF, or FLAC.");
    const auto bitDepth = juce::jlimit(16, 32, options.bitDepth);
    const auto projectState = dataModel->createProjectState();
    double endSample = 0.0;
    for (const auto& track : projectState.tracks)
        for (const auto& clip : track.clips)
            endSample = juce::jmax(endSample, clip.startSample + clip.durationSamples);
    for (const auto& clip : projectState.midiClips)
        for (const auto& note : clip.notes)
            endSample = juce::jmax(endSample, clip.startSample + note.startSample + note.durationSamples);
    if (options.useCycle && dataModel->isCycleActive()) endSample = dataModel->getCycleEndSample();
    if (endSample <= 0.0) return juce::Result::fail("Project has no audio to render");

    destination.deleteFile();
    auto stream = destination.createOutputStream();
    if (stream == nullptr) return juce::Result::fail("Cannot create offline render file");
    auto* rawStream = stream.release();
    std::unique_ptr<juce::AudioFormatWriter> writer(format->createWriterFor(rawStream, options.sampleRate, 2, bitDepth, {}, 0));
    if (writer == nullptr)
    {
        delete rawStream;
        return juce::Result::fail("Cannot create offline WAV writer");
    }

    const auto previousRate = dataModel->getSampleRate();
    const auto previousPlayhead = dataModel->getPlayheadPosition();
    const auto wasPlaying = dataModel->isPlaying();
    const auto cycleWasActive = dataModel->isCycleActive();
    const auto cycleStart = dataModel->getCycleStartSample();
    const auto cycleEnd = dataModel->getCycleEndSample();
    const auto previousProjectRevision = dataModel->getProjectRevision();
    const auto restoreTransport = [this, previousRate, previousPlayhead, wasPlaying,
                                   cycleWasActive, cycleStart, cycleEnd, previousProjectRevision]
    {
        dataModel->setSampleRate(previousRate);
        dataModel->setPlayheadPosition(previousPlayhead);
        dataModel->setPlaying(wasPlaying);
        if (cycleWasActive) dataModel->setCycle(cycleStart, cycleEnd); else dataModel->clearCycle();
        dataModel->restoreProjectRevision(previousProjectRevision);
    };
    dataModel->setSampleRate(options.sampleRate);
    if (! options.useCycle) dataModel->clearCycle();
    dataModel->setPlayheadPosition(options.useCycle && cycleWasActive ? cycleStart : 0.0);
    dataModel->setPlaying(true);
    processingBuffer.setSize(2, options.blockSize, false, true, true);
    for (auto& buffer : trackBuffers) buffer.setSize(2, options.blockSize, false, true, true);
    for (auto& buffer : busBuffers) buffer.setSize(2, options.blockSize, false, true, true);
    for (auto& midi : trackMidiBuffers) midi.ensureSize(MidiEventBuffer::capacity * 4);
    juce::AudioBuffer<float> renderBuffer(2, options.blockSize);
    float* outputs[] { renderBuffer.getWritePointer(0), renderBuffer.getWritePointer(1) };
    const auto totalSamples = static_cast<int64_t>(std::ceil(endSample));
    int64_t rendered = 0;
    while (rendered < totalSamples)
    {
        const auto count = static_cast<int>(juce::jmin<int64_t>(options.blockSize, totalSamples - rendered));
        audioDeviceIOCallbackWithContext(nullptr, 0, outputs, 2, count, {});
        if (! writer->writeFromAudioSampleBuffer(renderBuffer, 0, count))
        {
            restoreTransport();
            return juce::Result::fail("Offline WAV write failed");
        }
        rendered += count;
    }
    restoreTransport();
    return juce::Result::ok();
}

double AudioEngine::getTempo() const noexcept
{
    return dataModel != nullptr ? dataModel->getBpm() : 120.0;
}

void AudioEngine::setPlaybackState(bool shouldPlay) noexcept
{
    if (dataModel != nullptr)
        dataModel->setPlaying(shouldPlay);
}

bool AudioEngine::isPlaying() const noexcept
{
    return dataModel != nullptr && dataModel->isPlaying();
}

juce::AudioDeviceManager& AudioEngine::getAudioDeviceManager() noexcept
{
    return deviceManager;
}

juce::Array<int> AudioEngine::getActiveAudioInputChannels() const
{
    juce::Array<int> channels;
    const auto* device = deviceManager.getCurrentAudioDevice();
    if (device == nullptr)
        return channels;

    const auto active = device->getActiveInputChannels();
    for (int channel = 0; channel <= active.getHighestBit(); ++channel)
        if (active[channel])
            channels.add(channel);
    return channels;
}

void AudioEngine::refreshMidiInputDevices()
{
    // LIVE defaults to accepting every connected controller. The empty
    // callback identifier receives events from all enabled inputs; this owns
    // enabling a controller that appears after StudioForge has launched.
    const auto devices = juce::MidiInput::getAvailableDevices();
    juce::StringArray presentIdentifiers;
    for (const auto& device : devices)
    {
        presentIdentifiers.add(device.identifier);
        if (! deviceManager.isMidiInputDeviceEnabled(device.identifier))
            deviceManager.setMidiInputDeviceEnabled(device.identifier, true);
    }

    for (const auto& identifier : managedMidiInputIdentifiers)
        if (! presentIdentifiers.contains(identifier))
            deviceManager.setMidiInputDeviceEnabled(identifier, false);
    managedMidiInputIdentifiers = std::move(presentIdentifiers);
}

void AudioEngine::enableAllAvailableInputsOnFirstLaunch()
{
    auto* device = deviceManager.getCurrentAudioDevice();
    if (device == nullptr)
        return;

    const auto inputCount = device->getInputChannelNames().size();
    if (inputCount <= 0)
        return;

    auto setup = deviceManager.getAudioDeviceSetup();
    setup.inputChannels.clear();
    for (int channel = 0; channel < inputCount; ++channel)
        setup.inputChannels.setBit(channel);
    deviceManager.setAudioDeviceSetup(setup, true);
}

float AudioEngine::getTrackPeak(size_t trackIndex) const noexcept
{
    if ((! isPlaying() && ! isLivePerformanceEnabled()) || trackIndex >= trackPeaks.size())
        return 0.0f;
    return trackPeaks[trackIndex].load(std::memory_order_relaxed);
}

float AudioEngine::getTrackInputPeak(size_t trackIndex) const noexcept
{
    return trackIndex < trackInputPeaks.size()
        ? trackInputPeaks[trackIndex].load(std::memory_order_relaxed) : 0.0f;
}

float AudioEngine::getBusPeak(size_t busIndex) const noexcept
{
    if (! isPlaying() || busIndex >= busPeaks.size())
        return 0.0f;
    return busPeaks[busIndex].load(std::memory_order_relaxed);
}

float AudioEngine::getMasterPeak() const noexcept
{
    return isPlaying() ? masterPeak.load(std::memory_order_relaxed) : 0.0f;
}

float AudioEngine::getMasterLeftPeak() const noexcept
{
    return isPlaying() ? masterLeftPeak.load(std::memory_order_relaxed) : 0.0f;
}

float AudioEngine::getMasterRightPeak() const noexcept
{
    return isPlaying() ? masterRightPeak.load(std::memory_order_relaxed) : 0.0f;
}

AudioEngine::RealtimeDiagnostics AudioEngine::getRealtimeDiagnostics() const noexcept
{
    return { activeSampleRate.load(std::memory_order_relaxed),
             activeBufferSize.load(std::memory_order_relaxed),
             activeInputLatencySamples.load(std::memory_order_relaxed),
             activeOutputLatencySamples.load(std::memory_order_relaxed),
             getEstimatedLivePluginLatencySamples(),
             getLiveProtectedPluginCount(),
             callbackLoad.load(std::memory_order_relaxed),
             callbackOverloadCount.load(std::memory_order_relaxed),
             droppedMidiInputEvents.load(std::memory_order_relaxed),
             droppedMidiRecordingEvents.load(std::memory_order_relaxed) };
}

int AudioEngine::getEstimatedLivePluginLatencySamples() const noexcept
{
    auto longestTrackRack = 0;
    if (dataModel != nullptr)
        for (size_t trackIndex = 0; trackIndex < dataModel->getTrackCount(); ++trackIndex)
            longestTrackRack = juce::jmax(longestTrackRack, rackLatencySamples(dataModel->getFxRackSnapshot(trackIndex)));

    return longestTrackRack + rackLatencySamples(getMasterFxRackSnapshot());
}

int AudioEngine::getLiveProtectedPluginCount() const noexcept
{
    if (! isLiveLowLatencyProtectionEnabled())
        return 0;

    auto protectedCount = protectedPluginCount(getMasterFxRackSnapshot());
    if (dataModel == nullptr)
        return protectedCount;

    for (size_t trackIndex = 0; trackIndex < dataModel->getTrackCount(); ++trackIndex)
        protectedCount += protectedPluginCount(dataModel->getFxRackSnapshot(trackIndex));
    for (const auto& bus : dataModel->getBuses())
        protectedCount += protectedPluginCount(dataModel->getBusFxRackSnapshot(bus.id));
    return protectedCount;
}

LiveKeyDetector::Result AudioEngine::getLiveKeyResult() const noexcept
{
    return liveKeyDetector.getLatestResult();
}

int AudioEngine::applyDetectedKeyToPitchCorrection()
{
    const auto key = getLiveKeyResult();
    if (key.revision == 0 || key.confidence < 0.45f)
        return 0;

    return applyKeyToPitchCorrection(key.root, key.minor);
}

int AudioEngine::applyKeyToPitchCorrection(int rootNote, bool minor)
{
    auto applied = 0;
    const auto applyToRack = [&] (const TrackDataModel::FxRackSnapshot* rack)
    {
        if (rack == nullptr) return;
        for (const auto& processor : rack->processors)
            if (processor != nullptr && processor->applyDetectedKey(rootNote, minor))
                ++applied;
    };
    if (dataModel != nullptr)
        for (size_t index = 0; index < dataModel->getTrackCount(); ++index)
            applyToRack(dataModel->getFxRackSnapshot(index));
    applyToRack(getMasterFxRackSnapshot());
    return applied;
}

void AudioEngine::setFxProcessor(size_t trackIndex, size_t slot,
                                 std::shared_ptr<AudioEffectProcessor> processor)
{
    if (dataModel == nullptr || trackIndex >= TrackDataModel::maxTracks || slot >= TrackDataModel::maxFxSlots)
        return;

    auto* device = deviceManager.getCurrentAudioDevice();
    const auto sampleRate = device != nullptr ? device->getCurrentSampleRate()
                                              : dataModel->getSampleRate();
    const auto blockSize = device != nullptr ? device->getCurrentBufferSizeSamples() : 512;
    if (processor != nullptr)
        processor->prepareToPlay(sampleRate, blockSize, 2);
    dataModel->setFxProcessor(trackIndex, slot, std::move(processor));
}

void AudioEngine::setFxBypassed(size_t trackIndex, size_t slot, bool bypassed) noexcept
{
    if (dataModel != nullptr)
        dataModel->setFxBypassed(trackIndex, slot, bypassed);
}

const TrackDataModel::FxRackSnapshot* AudioEngine::getMasterFxRackSnapshot() const noexcept
{
    return publishedMasterFxRack.load(std::memory_order_acquire);
}

void AudioEngine::setMasterFxProcessor(size_t slot, std::shared_ptr<AudioEffectProcessor> processor)
{
    if (slot >= TrackDataModel::maxFxSlots) return;
    auto* device = deviceManager.getCurrentAudioDevice();
    const auto sampleRate = device != nullptr ? device->getCurrentSampleRate()
                                              : juce::jmax(activeSampleRate.load(std::memory_order_relaxed),
                                                           dataModel != nullptr ? dataModel->getSampleRate() : 44100.0);
    const auto blockSize = device != nullptr ? device->getCurrentBufferSizeSamples() : 512;
    if (processor != nullptr) processor->prepareToPlay(sampleRate, blockSize, 2);

    auto updated = std::make_unique<TrackDataModel::FxRackSnapshot>();
    if (const auto* current = getMasterFxRackSnapshot(); current != nullptr) *updated = *current;
    updated->processors[slot] = std::move(processor);
    publishMasterFxRack(std::move(updated));
}

void AudioEngine::setMasterFxBypassed(size_t slot, bool bypassed)
{
    if (slot >= TrackDataModel::maxFxSlots) return;
    auto updated = std::make_unique<TrackDataModel::FxRackSnapshot>();
    if (const auto* current = getMasterFxRackSnapshot(); current != nullptr) *updated = *current;
    updated->bypass[slot] = bypassed;
    publishMasterFxRack(std::move(updated));
}

void AudioEngine::prepareRack(const TrackDataModel::FxRackSnapshot* rack, double sampleRate, int blockSize)
{
    if (rack == nullptr || sampleRate <= 0.0 || blockSize <= 0)
        return;

    for (const auto& processor : rack->processors)
        if (processor != nullptr)
            processor->prepareToPlay(sampleRate, blockSize, 2);
}

int AudioEngine::rackLatencySamples(const TrackDataModel::FxRackSnapshot* rack) const noexcept
{
    if (rack == nullptr)
        return 0;

    auto latency = 0;
    for (size_t slot = 0; slot < TrackDataModel::maxFxSlots; ++slot)
        if (const auto& processor = rack->processors[slot]; processor != nullptr && ! rack->bypass[slot]
            && shouldProcessForLive(*processor))
            latency += processor->getLatencySamples();
    return latency;
}

int AudioEngine::protectedPluginCount(const TrackDataModel::FxRackSnapshot* rack) const noexcept
{
    if (rack == nullptr)
        return 0;

    auto count = 0;
    for (size_t slot = 0; slot < TrackDataModel::maxFxSlots; ++slot)
        if (const auto& processor = rack->processors[slot]; processor != nullptr && ! rack->bypass[slot]
            && ! processor->isMidiEffect() && ! shouldProcessForLive(*processor))
            ++count;
    return count;
}

bool AudioEngine::shouldProcessForLive(const AudioEffectProcessor& processor) const noexcept
{
    return ! (isLiveLowLatencyProtectionEnabled()
              && processor.getLatencySamples() > livePluginLatencyBudgetSamples);
}

void AudioEngine::prepareActiveEffects()
{
    auto* device = deviceManager.getCurrentAudioDevice();
    const auto sampleRate = device != nullptr ? device->getCurrentSampleRate()
                                              : juce::jmax(activeSampleRate.load(std::memory_order_relaxed),
                                                           dataModel != nullptr ? dataModel->getSampleRate() : 44100.0);
    const auto blockSize = device != nullptr ? device->getCurrentBufferSizeSamples()
                                             : juce::jmax(1, processingBuffer.getNumSamples());
    const auto resolvedSampleRate = sampleRate > 0.0 ? sampleRate : 44100.0;

    if (dataModel != nullptr)
    {
        dataModel->setSampleRate(resolvedSampleRate);
        for (size_t trackIndex = 0; trackIndex < TrackDataModel::maxTracks; ++trackIndex)
            prepareRack(dataModel->getFxRackSnapshot(trackIndex), resolvedSampleRate, blockSize);
        for (const auto& bus : dataModel->getBuses())
            prepareRack(dataModel->getBusFxRackSnapshot(bus.id), resolvedSampleRate, blockSize);
    }
    prepareRack(getMasterFxRackSnapshot(), resolvedSampleRate, blockSize);
}

void AudioEngine::publishMasterFxRack(std::unique_ptr<const TrackDataModel::FxRackSnapshot> snapshot)
{
    auto previous = std::move(masterFxRack);
    masterFxRack = std::move(snapshot);
    publishedMasterFxRack.store(masterFxRack.get(), std::memory_order_release);
    if (previous != nullptr) retiredMasterFxRacks.push_back(std::move(previous));
}

void AudioEngine::audioDeviceAboutToStart(juce::AudioIODevice* device)
{
    const auto outputChannels = device != nullptr ? device->getActiveOutputChannels().countNumberOfSetBits() : 2;
    const auto blockSize = device != nullptr ? device->getCurrentBufferSizeSamples() : 512;
    // CoreAudio can briefly change callback size while a USB interface
    // renegotiates its stream. Allocate to the driver's largest supported
    // block here (never in the callback) so a momentary larger callback does
    // not hit the early-silence guard in audioDeviceIOCallbackWithContext.
    auto bufferCapacity = juce::jmax(1, blockSize);
    if (device != nullptr)
        for (const auto candidate : device->getAvailableBufferSizes())
            bufferCapacity = juce::jmax(bufferCapacity, candidate);
    bufferCapacity = juce::jmax(bufferCapacity, 4096);
    activeSampleRate.store(device != nullptr ? device->getCurrentSampleRate() : 0.0, std::memory_order_relaxed);
    activeBufferSize.store(blockSize, std::memory_order_relaxed);
    activeInputLatencySamples.store(device != nullptr ? device->getInputLatencyInSamples() : 0, std::memory_order_relaxed);
    activeOutputLatencySamples.store(device != nullptr ? device->getOutputLatencyInSamples() : 0, std::memory_order_relaxed);
    callbackLoad.store(0.0f, std::memory_order_relaxed);
    rebuildInputChannelMap(device);
    rebuildOutputChannelMap(device);
    processingBuffer.setSize(juce::jmax(2, outputChannels), bufferCapacity,
                             false, true, true);
    streamBusBuffer.setSize(2, bufferCapacity, false, true, true);
    streamMonitorBuffer.setSize(2, bufferCapacity, false, true, true);
    cueMonitorBuffer.setSize(2, bufferCapacity, false, true, true);
    masterMonitorBuffer.setSize(2, bufferCapacity, false, true, true);
    for (auto& buffer : trackBuffers)
        buffer.setSize(2, processingBuffer.getNumSamples(), false, true, true);
    for (auto& buffer : busBuffers)
        buffer.setSize(2, processingBuffer.getNumSamples(), false, true, true);
    for (auto& midi : trackMidiBuffers)
        midi.ensureSize(MidiEventBuffer::capacity * 4);

    prepareActiveEffects();
}

void AudioEngine::audioDeviceStopped()
{
    if (recordingSession != nullptr && recordingSession->isRecording())
        recordingInterruptedByDeviceDisconnect.store(true, std::memory_order_release);
    // CoreAudio calls this for benign changes too (buffer-size/device setup).
    // Do not silently turn off a performer's MIC route: audioDeviceAboutToStart
    // rebuilds the physical map and resumes the persisted runtime route.
    processingBuffer.clear();
    for (auto& callbackChannel : callbackInputByPhysicalChannel)
        callbackChannel.store(-1, std::memory_order_release);
    for (auto& callbackChannel : callbackOutputByPhysicalChannel)
        callbackChannel.store(-1, std::memory_order_release);
    activeCallbackInputCount.store(0, std::memory_order_release);
    activeSampleRate.store(0.0, std::memory_order_relaxed);
    activeBufferSize.store(0, std::memory_order_relaxed);
}

void AudioEngine::rebuildInputChannelMap(const juce::AudioIODevice* device) noexcept
{
    for (auto& callbackChannel : callbackInputByPhysicalChannel)
        callbackChannel.store(-1, std::memory_order_relaxed);

    auto callbackChannel = 0;
    if (device != nullptr)
    {
        const auto active = device->getActiveInputChannels();
        for (int physicalChannel = 0; physicalChannel <= active.getHighestBit(); ++physicalChannel)
            if (active[physicalChannel])
            {
                if (physicalChannel < maximumPhysicalInputChannels)
                    callbackInputByPhysicalChannel[static_cast<size_t>(physicalChannel)].store(callbackChannel,
                                                                                                  std::memory_order_relaxed);
                ++callbackChannel;
            }
    }
    activeCallbackInputCount.store(callbackChannel, std::memory_order_release);
}

void AudioEngine::rebuildOutputChannelMap(const juce::AudioIODevice* device) noexcept
{
    for (auto& callbackChannel : callbackOutputByPhysicalChannel)
        callbackChannel.store(-1, std::memory_order_relaxed);
    if (device == nullptr) return;

    const auto active = device->getActiveOutputChannels();
    auto callbackChannel = 0;
    for (int physicalChannel = 0; physicalChannel <= active.getHighestBit(); ++physicalChannel)
        if (active[physicalChannel])
        {
            if (physicalChannel < maximumPhysicalInputChannels)
                callbackOutputByPhysicalChannel[static_cast<size_t>(physicalChannel)].store(callbackChannel,
                                                                                               std::memory_order_relaxed);
            ++callbackChannel;
        }
}

int AudioEngine::callbackOutputForPhysicalChannel(int physicalChannel) const noexcept
{
    if (physicalChannel < 0 || physicalChannel >= maximumPhysicalInputChannels)
        return -1;
    return callbackOutputByPhysicalChannel[static_cast<size_t>(physicalChannel)].load(std::memory_order_acquire);
}

int AudioEngine::callbackInputForPhysicalChannel(int physicalChannel) const noexcept
{
    if (physicalChannel < 0 || physicalChannel >= maximumPhysicalInputChannels)
        return -1;
    return callbackInputByPhysicalChannel[static_cast<size_t>(physicalChannel)].load(std::memory_order_acquire);
}

bool AudioEngine::isPhysicalInputRouteAvailable(int physicalChannel, int channelCount) const noexcept
{
    if (channelCount < 1 || channelCount > 2)
        return false;
    const auto firstCallbackChannel = callbackInputForPhysicalChannel(physicalChannel);
    if (firstCallbackChannel < 0)
        return false;
    if (channelCount == 1)
        return true;
    const auto secondCallbackChannel = callbackInputForPhysicalChannel(physicalChannel + 1);
    return secondCallbackChannel == firstCallbackChannel + 1;
}

void AudioEngine::handleIncomingMidiMessage(juce::MidiInput* source, const juce::MidiMessage& message)
{
    MidiRealtimeEvent event;
    if (! MidiRealtimeEvent::fromMessage(message, event))
        return;

    int start1 = 0, size1 = 0, start2 = 0, size2 = 0;
    incomingMidiFifo.prepareToWrite(1, start1, size1, start2, size2);
    if (size1 == 0)
    {
        droppedMidiInputEvents.fetch_add(1, std::memory_order_relaxed);
        return;
    }

    const auto token = source == nullptr ? 0u : static_cast<uint32_t>(source->getIdentifier().hashCode());
    incomingMidiEvents[static_cast<size_t>(start1)] = { event, token };
    incomingMidiFifo.finishedWrite(1);
}

AudioEngine::CallbackTimingScope::CallbackTimingScope(AudioEngine& owner, int samples) noexcept
    : engine(owner), numSamples(samples), started(std::chrono::steady_clock::now())
{
}

AudioEngine::CallbackTimingScope::~CallbackTimingScope()
{
    engine.recordCallbackTiming(numSamples, started);
}

void AudioEngine::recordCallbackTiming(int numSamples, std::chrono::steady_clock::time_point started) noexcept
{
    const auto sampleRate = activeSampleRate.load(std::memory_order_relaxed);
    if (sampleRate <= 0.0 || numSamples <= 0)
        return;

    const auto elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
    const auto blockDuration = static_cast<double>(numSamples) / sampleRate;
    const auto instantaneousLoad = static_cast<float>(elapsed / blockDuration);
    const auto previousLoad = callbackLoad.load(std::memory_order_relaxed);
    callbackLoad.store(previousLoad * 0.90f + instantaneousLoad * 0.10f, std::memory_order_relaxed);
    if (elapsed > blockDuration)
        callbackOverloadCount.fetch_add(1, std::memory_order_relaxed);
}

void AudioEngine::audioDeviceIOCallbackWithContext(const float* const* inputChannelData,
                                                   int numInputChannels,
                                                   float* const* outputChannelData,
                                                   int numOutputChannels,
                                                   int numSamples,
                                                   const juce::AudioIODeviceCallbackContext&)
{
    if (numSamples <= 0 || outputChannelData == nullptr)
        return;

    CallbackTimingScope callbackTiming(*this, numSamples);

    for (int channel = 0; channel < numOutputChannels; ++channel)
        juce::FloatVectorOperations::clear(outputChannelData[channel], numSamples);

    if (dataModel == nullptr || numSamples > processingBuffer.getNumSamples())
        return;

    captureRecordingInput(inputChannelData, numInputChannels, numSamples);

    const auto blockStartSample = dataModel->getPlayheadPosition();
    const auto snapshots = dataModel->acquireRealtimeSnapshot();
    const auto* clips = snapshots.getAudioClips();
    const auto* structure = snapshots.getRenderStructure();
    const auto* midiClips = snapshots.getMidiClips();
    const auto playing = dataModel->isPlaying();
    updateTrackInputPeaks(inputChannelData, numInputChannels, structure, numSamples);
    const auto hasMonitoredAudio = hasMonitoredAudioTracks(structure);
    const auto hasPendingMidi = incomingMidiFifo.getNumReady() > 0;
    const auto hasActiveInstrument = std::any_of(instrumentVoices.begin(), instrumentVoices.end(),
                                                 [] (const InstrumentVoice& voice) { return voice.active; });
    if (! playing && ! hasMonitoredAudio && ! hasPendingMidi && ! hasActiveInstrument)
        return;

    clearRealtimeBuffers(numSamples);

    scheduledMidiEvents.clear();
    if (playing && clips != nullptr && structure != nullptr)
    {
        const auto cycleActive = dataModel->isCycleActive();
        const auto cycleStart = dataModel->getCycleStartSample();
        const auto cycleEnd = dataModel->getCycleEndSample();
        auto playhead = TransportUtils::normalisePlayhead(dataModel->getPlayheadPosition(), cycleActive,
                                                          cycleStart, cycleEnd);
        int renderedSamples = 0;
        while (renderedSamples < numSamples)
        {
            const auto segmentSamples = TransportUtils::samplesUntilBoundary(
                playhead, numSamples - renderedSamples, cycleActive, cycleStart, cycleEnd);
            renderClipSegment(*clips, *structure, playhead, renderedSamples, segmentSamples);
            if (midiClips != nullptr)
            {
                MidiEventBuffer segmentEvents;
                MidiScheduler::scheduleBlock(*midiClips, playhead, segmentSamples, segmentEvents);
                for (size_t eventIndex = 0; eventIndex < segmentEvents.size(); ++eventIndex)
                {
                    auto event = segmentEvents[eventIndex];
                    event.sampleOffset += renderedSamples;
                    if (! scheduledMidiEvents.add(event))
                        break;
                }
            }
            playhead = TransportUtils::advance(playhead, segmentSamples, cycleActive, cycleStart, cycleEnd);
            renderedSamples += segmentSamples;
        }
        dataModel->setPlayheadPosition(playhead);
    }

    bool anyTrackSoloed = false;
    const auto automationSample = dataModel->getPlayheadPosition();
    for (size_t trackIndex = 0; structure != nullptr && trackIndex < structure->trackCount; ++trackIndex)
        anyTrackSoloed = anyTrackSoloed || structure->tracks[trackIndex].solo;

    prepareTrackMidiBuffers(structure);
    if (structure != nullptr)
        appendIncomingMidiEvents(*structure, blockStartSample);
    processTrackMidiEffects(structure);
    sendExternalMidi(structure);

    if (structure != nullptr)
        renderInstrument(*structure, numSamples);

    renderInputMonitoring(inputChannelData, numInputChannels, structure, numSamples);

    processTrackAudio(structure, automationSample, anyTrackSoloed, numSamples);
    processBusReturns(structure, numSamples);

    processMasterOutput(outputChannelData, numOutputChannels, numSamples, playing, blockStartSample);
    // The explicit I/MIC control owns this final raw monitor lane. It is not
    // dependent on an asynchronously published project snapshot, plug-in, or
    // automation state, so input cannot fade then latch off mid-performance.
    const auto directTrackId = directMonitorTrackId.load(std::memory_order_acquire);
    const auto directPhysicalInput = directMonitorPhysicalInput.load(std::memory_order_acquire);
    if (! panicMuteEnabled.load(std::memory_order_acquire) && directTrackId != 0 && directPhysicalInput >= 0)
    {
        auto audible = false;
        if (structure != nullptr)
        {
            auto anySolo = false;
            const TrackDataModel::RenderTrack* directTrack = nullptr;
            for (size_t index = 0; index < structure->trackCount; ++index)
            {
                anySolo = anySolo || structure->tracks[index].solo;
                if (structure->tracks[index].id.value == directTrackId)
                    directTrack = &structure->tracks[index];
            }
            audible = directTrack != nullptr && ! directTrack->muted
                && (! anySolo || directTrack->solo || directTrack->soloSafe);
        }
        const auto inputIndex = callbackInputForPhysicalChannel(directPhysicalInput);
        if (audible && inputIndex >= 0 && inputIndex < numInputChannels && inputChannelData[inputIndex] != nullptr)
            for (int channel = 0; channel < juce::jmin(2, numOutputChannels); ++channel)
                if (outputChannelData[channel] != nullptr)
                    juce::FloatVectorOperations::add(outputChannelData[channel], inputChannelData[inputIndex], numSamples);
    }
}

void AudioEngine::processMasterOutput(float* const* outputChannelData, int numOutputChannels,
                                      int numSamples, bool isPlaying, double blockStartSample) noexcept
{
    if (const auto* rack = publishedMasterFxRack.load(std::memory_order_acquire); rack != nullptr)
        for (size_t slot = 0; slot < TrackDataModel::maxFxSlots; ++slot)
            if (const auto& processor = rack->processors[slot]; processor != nullptr && !rack->bypass[slot]
                && shouldProcessForLive(*processor))
                processor->processBlock(processingBuffer);

    graph.process(processingBuffer, numSamples);
    if (isPlaying && (metronomeEnabled.load(std::memory_order_acquire)
                      || countInMetronomeActive.load(std::memory_order_acquire)))
        renderMetronome(blockStartSample, numSamples);
    // Keep the live microphone route deterministic: master/track plug-ins and
    // timeline automation cannot gate it as the playhead changes.
    for (int channel = 0; channel < juce::jmin(processingBuffer.getNumChannels(), masterMonitorBuffer.getNumChannels()); ++channel)
        processingBuffer.addFrom(channel, 0, masterMonitorBuffer, channel, 0, numSamples);
    if (isLivePerformanceEnabled())
        liveKeyDetector.push(processingBuffer, numSamples, activeSampleRate.load(std::memory_order_relaxed));
    // Do not hard-clip the mix here. A safety ceiling must be a true limiter;
    // clipping at this point corrupts normal bus/send gain sums.
    const auto streamChannels = juce::jmin(streamBusBuffer.getNumChannels(), processingBuffer.getNumChannels());
    for (int channel = 0; channel < streamChannels; ++channel)
        streamBusBuffer.copyFrom(channel, 0, processingBuffer, channel, 0, numSamples);
    for (int channel = 0; channel < juce::jmin(streamMonitorBuffer.getNumChannels(), streamBusBuffer.getNumChannels()); ++channel)
        streamBusBuffer.addFrom(channel, 0, streamMonitorBuffer, channel, 0, numSamples);
    // The stream bus is captured post-FX but before the physical-output Panic
    // gate. Stream Mute is intentionally applied only by the bridge consumer.
    publishStreamOutput(streamBusBuffer, numSamples);
    if (panicMuteEnabled.load(std::memory_order_acquire))
    {
        processingBuffer.clear(0, numSamples);
        cueMonitorBuffer.clear(0, numSamples);
    }
    masterPeak.store(TrackMixing::peak(processingBuffer, numSamples), std::memory_order_relaxed);
    masterLeftPeak.store(peakForChannel(processingBuffer, 0, numSamples), std::memory_order_relaxed);
    masterRightPeak.store(peakForChannel(processingBuffer, 1, numSamples), std::memory_order_relaxed);
    for (int channel = 0; channel < numOutputChannels; ++channel)
        if (outputChannelData[channel] != nullptr)
            juce::FloatVectorOperations::clear(outputChannelData[channel], numSamples);
    for (int channel = 0; channel < juce::jmin(2, juce::jmin(numOutputChannels, processingBuffer.getNumChannels())); ++channel)
        if (outputChannelData[channel] != nullptr)
            juce::FloatVectorOperations::copy(outputChannelData[channel], processingBuffer.getReadPointer(channel), numSamples);
    const auto cueLeft = callbackOutputForPhysicalChannel(2);
    const auto cueRight = callbackOutputForPhysicalChannel(3);
    if (cueLeft >= 0 && cueLeft < numOutputChannels && outputChannelData[cueLeft] != nullptr)
        juce::FloatVectorOperations::copy(outputChannelData[cueLeft], cueMonitorBuffer.getReadPointer(0), numSamples);
    if (cueRight >= 0 && cueRight < numOutputChannels && outputChannelData[cueRight] != nullptr)
        juce::FloatVectorOperations::copy(outputChannelData[cueRight], cueMonitorBuffer.getReadPointer(1), numSamples);
}

void AudioEngine::prepareTrackMidiBuffers(const TrackDataModel::RenderStructureSnapshot* structure) noexcept
{
    for (auto& midiBuffer : trackMidiBuffers)
        midiBuffer.clear();
    if (structure == nullptr) return;
    for (size_t eventIndex = 0; eventIndex < scheduledMidiEvents.size(); ++eventIndex)
    {
        const auto& event = scheduledMidiEvents[eventIndex];
        const auto trackIndex = structure->getTrackIndex(event.trackId);
        if (trackIndex < 0) continue;
        const auto message = event.noteOn ? juce::MidiMessage::noteOn(event.channel, event.pitch, event.velocity)
                                          : juce::MidiMessage::noteOff(event.channel, event.pitch);
        trackMidiBuffers[static_cast<size_t>(trackIndex)].addEvent(message, event.sampleOffset);
    }
}

void AudioEngine::processTrackAudio(const TrackDataModel::RenderStructureSnapshot* structure,
                                    double automationSample, bool anyTrackSoloed, int numSamples) noexcept
{
    if (structure == nullptr) return;
    for (size_t trackIndex = 0; trackIndex < structure->trackCount; ++trackIndex)
    {
        auto& trackBuffer = trackBuffers[trackIndex];
        const auto& track = structure->tracks[trackIndex];
        if (track.fxRack != nullptr)
            for (size_t slot = 0; slot < TrackDataModel::maxFxSlots; ++slot)
                if (const auto& processor = track.fxRack->processors[slot]; processor != nullptr
                    && ! track.fxRack->bypass[slot] && ! processor->isMidiEffect()
                    && shouldProcessForLive(*processor))
                    processor->processBlock(trackBuffer, trackMidiBuffers[trackIndex]);


        const auto sendLevel = [&track, automationSample] (size_t route) noexcept
        {
            const auto& send = track.sends[route];
            return send.automation.mode == AutomationMode::read && send.automation.pointCount > 0
                ? send.automation.evaluate(automationSample) : send.level;
        };
        for (size_t route = 0; route < TrackDataModel::maxSendsPerTrack; ++route)
            if (track.sends[route].targetBus.isValid() && track.sends[route].preFader)
                addTrackToBus(track, trackIndex, trackBuffer, structure, route, sendLevel(route), numSamples);

        const auto volume = track.volumeAutomation.mode == AutomationMode::read && track.volumeAutomation.pointCount > 0
            ? track.volumeAutomation.evaluate(automationSample) : track.volume;
        const auto pan = track.panAutomation.mode == AutomationMode::read && track.panAutomation.pointCount > 0
            ? track.panAutomation.evaluate(automationSample) : track.pan;
        TrackMixing::apply(trackBuffer, numSamples, { volume, pan, !track.muted && (!anyTrackSoloed || track.solo || track.soloSafe) });
        trackPeaks[trackIndex].store(TrackMixing::peak(trackBuffer, numSamples), std::memory_order_relaxed);

        auto& destination = structure->getBusIndex(track.outputBus) >= 0
            ? busBuffers[static_cast<size_t>(structure->getBusIndex(track.outputBus))] : processingBuffer;
        for (int channel = 0; channel < juce::jmin(trackBuffer.getNumChannels(), destination.getNumChannels()); ++channel)
            juce::FloatVectorOperations::add(destination.getWritePointer(channel), trackBuffer.getReadPointer(channel), numSamples);
        for (size_t route = 0; route < TrackDataModel::maxSendsPerTrack; ++route)
            if (track.sends[route].targetBus.isValid() && ! track.sends[route].preFader)
                addTrackToBus(track, trackIndex, trackBuffer, structure, route, sendLevel(route), numSamples);
    }
}

void AudioEngine::processBusReturns(const TrackDataModel::RenderStructureSnapshot* structure, int numSamples) noexcept
{
    if (structure == nullptr) return;
    for (size_t busIndex = 0; busIndex < structure->busCount; ++busIndex)
    {
        const auto& bus = structure->buses[busIndex];
        if (bus.fxRack != nullptr)
            for (size_t slot = 0; slot < TrackDataModel::maxFxSlots; ++slot)
                if (const auto& processor = bus.fxRack->processors[slot]; processor != nullptr && ! bus.fxRack->bypass[slot]
                    && shouldProcessForLive(*processor))
                    processor->processBlock(busBuffers[busIndex]);
        if (bus.muted) busBuffers[busIndex].clear(0, numSamples);
        else for (int channel = 0; channel < busBuffers[busIndex].getNumChannels(); ++channel)
            busBuffers[busIndex].applyGain(channel, 0, numSamples, bus.gain);
        busPeaks[busIndex].store(TrackMixing::peak(busBuffers[busIndex], numSamples), std::memory_order_relaxed);
        for (int channel = 0; channel < juce::jmin(busBuffers[busIndex].getNumChannels(), processingBuffer.getNumChannels()); ++channel)
            juce::FloatVectorOperations::add(processingBuffer.getWritePointer(channel), busBuffers[busIndex].getReadPointer(channel), numSamples);
    }
}

void AudioEngine::addTrackToBus(const TrackDataModel::RenderTrack& track,
                                size_t trackIndex,
                                const juce::AudioBuffer<float>& source,
                                const TrackDataModel::RenderStructureSnapshot* structure,
                                size_t route, float level, int numSamples) noexcept
{
    const auto busIndex = structure->getBusIndex(track.sends[route].targetBus);
    if (busIndex < 0) return;
    auto& destination = busBuffers[static_cast<size_t>(busIndex)];
    const auto targetGain = juce::jlimit(0.0f, TrackDataModel::maximumSendGain, level);
    auto& previousGain = smoothedSendGains[trackIndex][route];
    // A newly-created route must be audible at its configured level on the
    // first callback. Subsequent automation still uses a ramp to avoid steps.
    if (previousGain == 0.0f && targetGain > 0.0f)
        previousGain = targetGain;
    for (int channel = 0; channel < juce::jmin(source.getNumChannels(), destination.getNumChannels()); ++channel)
        destination.addFromWithRamp(channel, 0, source.getReadPointer(channel), numSamples, previousGain, targetGain);
    previousGain = targetGain;
}

void AudioEngine::processTrackMidiEffects(const TrackDataModel::RenderStructureSnapshot* structure) noexcept
{
    if (structure == nullptr) return;
    for (size_t trackIndex = 0; trackIndex < structure->trackCount; ++trackIndex)
        if (const auto* rack = structure->tracks[trackIndex].fxRack; rack != nullptr)
            for (size_t slot = 0; slot < TrackDataModel::maxFxSlots; ++slot)
                if (const auto& processor = rack->processors[slot]; processor != nullptr && ! rack->bypass[slot]
                    && processor->isMidiEffect())
                    processor->processBlock(trackBuffers[trackIndex], trackMidiBuffers[trackIndex]);
}

void AudioEngine::sendExternalMidi(const TrackDataModel::RenderStructureSnapshot* structure) noexcept
{
    if (structure == nullptr)
        return;

    midiOutputCallbackUsers.fetch_add(1, std::memory_order_acq_rel);
    auto* output = publishedMidiOutput.load(std::memory_order_acquire);
    if (output != nullptr)
        for (size_t trackIndex = 0; trackIndex < structure->trackCount; ++trackIndex)
            if (structure->tracks[trackIndex].type == TrackType::externalMidi)
                for (const auto metadata : trackMidiBuffers[trackIndex])
                    output->sendMessageNow(metadata.getMessage());
    midiOutputCallbackUsers.fetch_sub(1, std::memory_order_acq_rel);
}

void AudioEngine::captureRecordingInput(const float* const* inputChannelData,
                                        int numInputChannels, int numSamples) noexcept
{
    if (recordingSession == nullptr) return;
    auto captureOffset = 0;
    auto captureSamples = numSamples;
    if (recordingCaptureRangeActive.load(std::memory_order_acquire))
    {
        if (! dataModel->isPlaying()) captureSamples = 0;
        else
        {
            const auto blockStart = dataModel->getPlayheadPosition();
            const auto rangeStart = recordingCaptureStartSample.load(std::memory_order_acquire);
            const auto rangeEnd = recordingCaptureEndSample.load(std::memory_order_acquire);
            captureOffset = juce::jlimit(0, numSamples, static_cast<int>(std::ceil(rangeStart - blockStart)));
            const auto captureEnd = juce::jlimit(0, numSamples, static_cast<int>(std::ceil(rangeEnd - blockStart)));
            captureSamples = juce::jmax(0, captureEnd - captureOffset);
        }
    }
    if (captureSamples > 0)
        recordingSession->capture(inputChannelData, numInputChannels, captureOffset, captureSamples);
}

bool AudioEngine::hasMonitoredAudioTracks(const TrackDataModel::RenderStructureSnapshot* structure) const noexcept
{
    if (structure == nullptr) return false;
    for (size_t index = 0; index < structure->trackCount; ++index)
        if (isInputMonitoringEligible(structure->tracks[index]))
            return true;
    return false;
}

bool AudioEngine::isInputMonitoringEligible(const TrackDataModel::RenderTrack& track) const noexcept
{
    return resolveMonitor(track).emit;
}

AudioEngine::MonitorDecision AudioEngine::resolveMonitor(const TrackDataModel::RenderTrack& track) const noexcept
{
    const auto eligible = track.type == TrackType::audio
        && (track.inputMonitoring || (track.autoInputMonitoring && track.armed));
    if (! eligible || ! track.monitorPermitted || track.monitorDestination == MonitorDestination::off)
        return {};

    return { true, track.monitorDestination };
}

void AudioEngine::renderInputMonitoring(const float* const* inputChannelData, int numInputChannels,
                                        const TrackDataModel::RenderStructureSnapshot* structure,
                                        int numSamples) noexcept
{
    if (structure == nullptr
        || inputChannelData == nullptr || numInputChannels <= 0) return;

    constexpr size_t maximumSafeInputChannels = 64;
    // Monitoring is unity-gain like a hardware console. Feedback safety comes
    // from the explicit global LIVE gate, not from silently attenuating input.
    constexpr float liveSoftwareMonitorGain = 1.0f;
    std::array<int, maximumSafeInputChannels> monitorOwner;
    monitorOwner.fill(-1);
    const auto focusedTrack = focusedMonitorTrackId.load(std::memory_order_acquire);

    // In a live setup, distinct physical inputs may all be monitored. When
    // several tracks reference one input, only one reaches the master. The
    // currently focused track wins the tie, otherwise the first route wins.
    for (size_t trackIndex = 0; trackIndex < structure->trackCount; ++trackIndex)
    {
        const auto& track = structure->tracks[trackIndex];
        if (! isInputMonitoringEligible(track) || track.inputChannel < 0
            || track.inputChannel >= static_cast<int>(maximumSafeInputChannels))
            continue;

        if (callbackInputForPhysicalChannel(track.inputChannel) < 0)
            continue;

        auto& owner = monitorOwner[static_cast<size_t>(track.inputChannel)];
        if (owner < 0 || track.id.value == focusedTrack)
            owner = static_cast<int>(trackIndex);
    }

    for (size_t trackIndex = 0; trackIndex < structure->trackCount; ++trackIndex)
    {
        const auto& track = structure->tracks[trackIndex];
        if (! isInputMonitoringEligible(track))
            continue;
        if (track.inputChannel < 0
            || track.inputChannel >= static_cast<int>(maximumSafeInputChannels)
            || monitorOwner[static_cast<size_t>(track.inputChannel)] != static_cast<int>(trackIndex))
            continue;

        const auto monitor = resolveMonitor(track);
        if (monitor.destination == MonitorDestination::master
            && directMonitorTrackId.load(std::memory_order_acquire) == track.id.value)
            continue;
        auto* destination = monitor.destination == MonitorDestination::cue ? &cueMonitorBuffer
                          : monitor.destination == MonitorDestination::streamOnly ? &streamMonitorBuffer
                          : &masterMonitorBuffer;
        const auto anyTrackSoloed = [&] () noexcept
        {
            for (size_t index = 0; index < structure->trackCount; ++index)
                if (structure->tracks[index].solo)
                    return true;
            return false;
        }();
        const auto audible = ! track.muted && (! anyTrackSoloed || track.solo || track.soloSafe);
        if (! audible)
            continue;
        const auto gain = juce::jmax(0.0f, track.volume);
        const auto angle = (juce::jlimit(-1.0f, 1.0f, track.pan) + 1.0f)
            * (juce::MathConstants<float>::pi * 0.25f);
        for (int channel = 0; channel < destination->getNumChannels(); ++channel)
        {
            const auto physicalInput = track.inputChannel + (track.inputChannelCount == 2 ? channel : 0);
            const auto inputIndex = callbackInputForPhysicalChannel(physicalInput);
            if (inputIndex < 0 || inputIndex >= numInputChannels)
                continue;
            if (const auto* input = inputChannelData[inputIndex]; input != nullptr)
            {
                // Master monitoring bypasses track FX and automation. It still
                // honours the visible track fader/pan/mute/solo controls.
                const auto panGain = monitor.destination == MonitorDestination::master
                    ? gain * (channel == 0 ? std::cos(angle) : std::sin(angle)) : 1.0f;
                destination->addFrom(channel, 0, input, numSamples, liveSoftwareMonitorGain * panGain);
            }
        }
    }
}

void AudioEngine::updateTrackInputPeaks(const float* const* inputChannelData, int numInputChannels,
                                        const TrackDataModel::RenderStructureSnapshot* structure,
                                        int numSamples) noexcept
{
    const auto trackCount = structure != nullptr ? structure->trackCount : 0;
    for (size_t trackIndex = 0; trackIndex < trackInputPeaks.size(); ++trackIndex)
    {
        if (trackIndex >= trackCount || inputChannelData == nullptr || numInputChannels <= 0)
        {
            trackInputPeaks[trackIndex].store(0.0f, std::memory_order_relaxed);
            continue;
        }

        const auto& track = structure->tracks[trackIndex];
        if (track.type != TrackType::audio || track.inputChannel < 0
            || callbackInputForPhysicalChannel(track.inputChannel) < 0)
        {
            trackInputPeaks[trackIndex].store(0.0f, std::memory_order_relaxed);
            continue;
        }

        auto peak = 0.0f;
        for (int offset = 0; offset < track.inputChannelCount; ++offset)
        {
            const auto inputIndex = callbackInputForPhysicalChannel(track.inputChannel + offset);
            if (inputIndex < 0 || inputIndex >= numInputChannels || inputChannelData[inputIndex] == nullptr)
                continue;
            const auto range = juce::FloatVectorOperations::findMinAndMax(inputChannelData[inputIndex], numSamples);
            peak = juce::jmax(peak, juce::jmax(std::abs(range.getStart()), std::abs(range.getEnd())));
        }
        trackInputPeaks[trackIndex].store(peak, std::memory_order_relaxed);
    }
}

void AudioEngine::clearRealtimeBuffers(int numSamples) noexcept
{
    processingBuffer.clear(0, numSamples);
    streamMonitorBuffer.clear(0, numSamples);
    cueMonitorBuffer.clear(0, numSamples);
    masterMonitorBuffer.clear(0, numSamples);
    for (auto& trackBuffer : trackBuffers)
        trackBuffer.clear(0, numSamples);
    for (auto& busBuffer : busBuffers)
        busBuffer.clear(0, numSamples);
    for (auto& busPeak : busPeaks)
        busPeak.store(0.0f, std::memory_order_relaxed);
}

void AudioEngine::renderMetronome(double blockStartSample, int numSamples) noexcept
{
    if (dataModel == nullptr || processingBuffer.getNumChannels() == 0)
        return;

    const auto sampleRate = juce::jmax(1.0, activeSampleRate.load(std::memory_order_relaxed));
    const auto bpm = dataModel->getTempoAtSample(blockStartSample);
    const auto samplesPerBeat = sampleRate * 60.0 / juce::jmax(1.0, bpm);
    const auto beatsPerBar = juce::jmax(1, dataModel->getTimeSignatureNumerator());
    const auto firstBeat = static_cast<long long>(std::floor(blockStartSample / samplesPerBeat));
    const auto lastBeat = static_cast<long long>(std::floor((blockStartSample + numSamples - 1) / samplesPerBeat));
    constexpr int clickLength = 192;

    for (auto beat = firstBeat; beat <= lastBeat; ++beat)
    {
        const auto beatSample = static_cast<double>(beat) * samplesPerBeat;
        const auto offset = static_cast<int>(std::llround(beatSample - blockStartSample));
        const auto start = juce::jmax(0, offset);
        const auto end = juce::jmin(numSamples, offset + clickLength);
        if (start >= end)
            continue;

        const auto accent = (beat % beatsPerBar) == 0;
        const auto frequency = accent ? 1760.0 : 1320.0;
        const auto amplitude = accent ? 0.16f : 0.10f;
        for (int sample = start; sample < end; ++sample)
        {
            const auto age = sample - offset;
            const auto envelope = std::exp(-static_cast<float>(age) / 42.0f);
            const auto value = amplitude * envelope * std::sin(static_cast<float>(juce::MathConstants<double>::twoPi
                * frequency * static_cast<double>(age) / sampleRate));
            for (int channel = 0; channel < processingBuffer.getNumChannels(); ++channel)
                processingBuffer.addSample(channel, sample, value);
        }
    }
}

void AudioEngine::appendIncomingMidiEvents(const TrackDataModel::RenderStructureSnapshot& structure,
                                           double blockStartSample) noexcept
{
    int start1 = 0, size1 = 0, start2 = 0, size2 = 0;
    incomingMidiFifo.prepareToRead(incomingMidiCapacity, start1, size1, start2, size2);
    const auto appendRange = [this, &structure, blockStartSample] (int start, int count) noexcept
    {
        for (int offset = 0; offset < count; ++offset)
        {
            const auto& event = incomingMidiEvents[static_cast<size_t>(start + offset)];
            const auto channelMatches = [&event] (const TrackDataModel::RenderTrack& track) noexcept
            {
                return track.midiInputChannel == 0 || track.midiInputChannel == event.message.channel;
            };
            const auto acceptsMidi = [&channelMatches, &event] (const TrackDataModel::RenderTrack& track) noexcept
            {
                return (track.type == TrackType::instrument || track.type == TrackType::externalMidi)
                    && channelMatches(track)
                    && (track.midiInputDeviceToken == 0 || track.midiInputDeviceToken == event.sourceDeviceToken);
            };

            bool hasArmedMidiTrack = false;
            for (size_t trackIndex = 0; trackIndex < structure.trackCount; ++trackIndex)
                hasArmedMidiTrack = hasArmedMidiTrack || (structure.tracks[trackIndex].armed && acceptsMidi(structure.tracks[trackIndex]));

            bool deliveredToRecordingTrack = false;
            for (size_t trackIndex = 0; trackIndex < structure.trackCount; ++trackIndex)
            {
                const auto& track = structure.tracks[trackIndex];
                if (! acceptsMidi(track) || (hasArmedMidiTrack && ! track.armed))
                    continue;

                trackMidiBuffers[trackIndex].addEvent(event.message.toMessage(), 0);
                deliveredToRecordingTrack = deliveredToRecordingTrack || track.id == midiRecordingTrack;
            }

            const auto isNote = event.message.type == MidiMessageType::noteOn || event.message.type == MidiMessageType::noteOff;
            if (isNote && deliveredToRecordingTrack && midiRecordingActive.load(std::memory_order_acquire))
            {
                midiRecordingCallbackUsers.fetch_add(1, std::memory_order_acq_rel);
                if (midiRecordingActive.load(std::memory_order_acquire))
                {
                    int writeStart1 = 0, writeSize1 = 0, writeStart2 = 0, writeSize2 = 0;
                    recordedMidiFifo.prepareToWrite(1, writeStart1, writeSize1, writeStart2, writeSize2);
                    if (writeSize1 > 0)
                    {
                        recordedMidiEvents[static_cast<size_t>(writeStart1)] = {
                            blockStartSample, event.message.data1, event.message.data2 / 127.0f,
                            event.message.channel, event.message.type == MidiMessageType::noteOn
                        };
                        recordedMidiFifo.finishedWrite(1);
                    }
                    else
                    {
                        droppedMidiRecordingEvents.fetch_add(1, std::memory_order_relaxed);
                    }
                }
                midiRecordingCallbackUsers.fetch_sub(1, std::memory_order_acq_rel);
            }
        }
    };
    appendRange(start1, size1);
    appendRange(start2, size2);
    incomingMidiFifo.finishedRead(size1 + size2);
}

void AudioEngine::renderInstrument(const TrackDataModel::RenderStructureSnapshot& structure, int numSamples) noexcept
{
    const auto rate = dataModel != nullptr ? dataModel->getSampleRate() : 44100.0;
    for (size_t trackIndex = 0; trackIndex < structure.trackCount; ++trackIndex)
    {
        if (structure.tracks[trackIndex].type != TrackType::instrument)
            continue;

        juce::MidiBuffer::Iterator events(trackMidiBuffers[trackIndex]);
        juce::MidiMessage message;
        int eventSample = 0;
        auto hasEvent = events.getNextEvent(message, eventSample);
        auto& voice = instrumentVoices[trackIndex];
        for (int sample = 0; sample < numSamples; ++sample)
        {
            while (hasEvent && eventSample <= sample)
            {
                if (message.isNoteOn())
                {
                    voice.active = true;
                    voice.pitch = message.getNoteNumber();
                    voice.velocity = message.getFloatVelocity();
                }
                else if (message.isNoteOff() && voice.pitch == message.getNoteNumber())
                {
                    voice.active = false;
                }
                hasEvent = events.getNextEvent(message, eventSample);
            }
            if (! voice.active) continue;
            const auto frequency = 440.0 * std::pow(2.0, (voice.pitch - 69) / 12.0);
            const auto value = static_cast<float>(std::sin(voice.phase) * voice.velocity * 0.2);
            voice.phase += (juce::MathConstants<double>::twoPi * frequency) / rate;
            if (voice.phase >= juce::MathConstants<double>::twoPi) voice.phase -= juce::MathConstants<double>::twoPi;
            for (int channel = 0; channel < trackBuffers[trackIndex].getNumChannels(); ++channel)
                trackBuffers[trackIndex].addSample(channel, sample, value);
        }
    }
}

void AudioEngine::renderClipSegment(const std::vector<AudioClipState>& clips,
                                    const TrackDataModel::RenderStructureSnapshot& structure,
                                    double segmentStartSample, int destinationOffset,
                                    int numSamples) noexcept
{
    const auto segmentEndSample = segmentStartSample + numSamples;
    for (const auto& clip : clips)
    {
        const auto trackIndex = structure.getTrackIndex(clip.trackId);
        if (clip.cachedBuffer == nullptr || clip.cachedBuffer->getNumChannels() == 0 || trackIndex < 0
            || static_cast<size_t>(trackIndex) >= trackBuffers.size())
            continue;

        const auto overlapStart = juce::jmax(segmentStartSample, clip.startSample);
        const auto overlapEnd = juce::jmin(segmentEndSample, clip.startSample + clip.durationSamples);
        if (overlapEnd <= overlapStart)
            continue;

        const auto segmentOffset = destinationOffset + static_cast<int>(overlapStart - segmentStartSample);
        const auto sourceOffset = static_cast<int>(clip.sourceOffsetSamples + overlapStart - clip.startSample);
        if (sourceOffset < 0 || sourceOffset >= clip.cachedBuffer->getNumSamples())
            continue;
        const auto samplesToCopy = juce::jmin(static_cast<int>(overlapEnd - overlapStart),
                                              clip.cachedBuffer->getNumSamples() - sourceOffset);
        if (samplesToCopy <= 0)
            continue;
        for (int sample = 0; sample < samplesToCopy; ++sample)
        {
            const auto clipSample = overlapStart - clip.startSample + sample;
            auto gain = clip.gain;
            if (clip.fadeInSamples > 0.0 && clipSample < clip.fadeInSamples)
                gain *= static_cast<float>(clipSample / clip.fadeInSamples);
            const auto fadeOutStart = clip.durationSamples - clip.fadeOutSamples;
            if (clip.fadeOutSamples > 0.0 && clipSample > fadeOutStart)
                gain *= static_cast<float>((clip.durationSamples - clipSample) / clip.fadeOutSamples);
            for (int channel = 0; channel < trackBuffers[static_cast<size_t>(trackIndex)].getNumChannels(); ++channel)
            {
                const auto sourceChannel = juce::jmin(channel, clip.cachedBuffer->getNumChannels() - 1);
                trackBuffers[static_cast<size_t>(trackIndex)].addSample(channel, segmentOffset + sample,
                    clip.cachedBuffer->getSample(sourceChannel, sourceOffset + sample) * gain);
            }
        }
    }
}
